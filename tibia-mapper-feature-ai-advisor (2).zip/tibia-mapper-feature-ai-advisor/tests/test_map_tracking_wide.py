import unittest

from map_tracking_wide import (
    WIDE_MIN_GAP,
    WIDE_MIN_SCORE,
    _default_calibration,
    _find_ordered_plan_indices,
    direction_between,
    first_path_direction,
    next_target_after_reach,
    wide_match_is_confident,
)


class LiveWideTrackerTests(unittest.TestCase):
    def test_confidence_requires_score_and_gap(self):
        self.assertTrue(wide_match_is_confident(.988, .3754))
        self.assertFalse(wide_match_is_confident(WIDE_MIN_SCORE - .001, .50))
        self.assertFalse(wide_match_is_confident(.99, WIDE_MIN_GAP - .001))

    def test_reference_calibration_matches_proven_targuna_values(self):
        calibration = _default_calibration(1008, 1036)
        self.assertAlmostEqual(calibration.center_x, 510.0, places=3)
        self.assertAlmostEqual(calibration.center_y, 518.0, places=3)
        self.assertAlmostEqual(calibration.tile_width, 37.833, places=3)
        self.assertAlmostEqual(calibration.tile_height, 38.370, places=3)
        self.assertAlmostEqual(calibration.patch_fraction, .18, places=3)

    def test_reference_calibration_scales_with_crop(self):
        calibration = _default_calibration(504, 518)
        self.assertAlmostEqual(calibration.center_x, 255.0, places=3)
        self.assertAlmostEqual(calibration.center_y, 259.0, places=3)
        self.assertAlmostEqual(calibration.tile_width, 18.9165, places=3)
        self.assertAlmostEqual(calibration.tile_height, 19.185, places=3)

    def test_saved_route_points_map_to_ordered_plan_indices(self):
        plan = [(0, 0), (1, 0), (2, 0), (2, 1), (2, 2), (3, 2)]
        targets = [(0, 0), (2, 0), (2, 2), (3, 2)]
        self.assertEqual(_find_ordered_plan_indices(plan, targets), [0, 2, 4, 5])

    def test_repeated_route_point_uses_later_occurrence_in_order(self):
        plan = [(0, 0), (1, 0), (0, 0), (0, 1)]
        targets = [(0, 0), (0, 0), (0, 1)]
        self.assertEqual(_find_ordered_plan_indices(plan, targets), [0, 0, 3])

    def test_missing_saved_point_is_rejected(self):
        with self.assertRaises(ValueError):
            _find_ordered_plan_indices([(0, 0), (1, 0)], [(0, 0), (2, 0)])

    def test_non_final_checkpoint_advances_normally(self):
        self.assertEqual(next_target_after_reach(0, 3, False), (1, False))
        self.assertEqual(next_target_after_reach(1, 3, True), (2, False))

    def test_last_checkpoint_finishes_when_repeat_is_disabled(self):
        self.assertEqual(next_target_after_reach(2, 3, False), (3, False))

    def test_last_checkpoint_wraps_to_first_when_repeat_is_enabled(self):
        self.assertEqual(next_target_after_reach(2, 3, True), (0, True))

    def test_cardinal_direction_helpers(self):
        self.assertEqual(direction_between((10, 10), (11, 10)), 'Este')
        self.assertEqual(direction_between((10, 10), (9, 10)), 'Oeste')
        self.assertEqual(direction_between((10, 10), (10, 11)), 'Sur')
        self.assertEqual(direction_between((10, 10), (10, 9)), 'Norte')
        self.assertIsNone(direction_between((10, 10), (11, 11)))
        self.assertEqual(first_path_direction([(5, 5), (5, 6), (6, 6)]), 'Sur')
        self.assertIsNone(first_path_direction([(5, 5)]))


if __name__ == '__main__':
    unittest.main()
