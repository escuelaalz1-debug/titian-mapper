import base64
import io
import json
import unittest
from unittest.mock import patch
from PIL import Image
from obs_scene_capture import capture_scene, capture_source


class ObsCaptureTests(unittest.TestCase):
    def test_authenticated_scene_request_and_decode(self):
        buffer=io.BytesIO();Image.new('RGB',(12,10),(4,5,6)).save(buffer,format='PNG')
        messages=[{'op':0,'d':{'authentication':{'salt':'salt','challenge':'challenge'}}},
                  {'op':2,'d':{}},{'op':7,'d':{'requestStatus':{'result':True},'responseData':{'imageData':'data:image/png;base64,'+base64.b64encode(buffer.getvalue()).decode()}}}]
        with patch('websocket.create_connection') as connect:
            socket=connect.return_value;socket.recv.side_effect=[json.dumps(m) for m in messages]
            image=capture_scene(password='example')
            self.assertEqual(image.getpixel((0,0)),(4,5,6))
            sent=[json.loads(c.args[0]) for c in socket.send.call_args_list]
            self.assertIn('authentication',sent[0]['d'])
            self.assertEqual(sent[1]['d']['requestData'],{'sourceName':'PanelDatos','imageFormat':'png'})
            socket.close.assert_called_once()

    def test_minimap_source_is_requested_directly(self):
        buffer=io.BytesIO();Image.new('RGB',(106,106),(1,2,3)).save(buffer,format='PNG')
        messages=[{'op':0,'d':{}},{'op':2,'d':{}},{'op':7,'d':{'requestStatus':{'result':True},'responseData':{'imageData':'data:image/png;base64,'+base64.b64encode(buffer.getvalue()).decode()}}}]
        with patch('websocket.create_connection') as connect:
            socket=connect.return_value;socket.recv.side_effect=[json.dumps(m) for m in messages]
            image=capture_source('Mapa')
            self.assertEqual(image.size,(106,106))
            sent=[json.loads(c.args[0]) for c in socket.send.call_args_list]
            self.assertEqual(sent[1]['d']['requestData'],{'sourceName':'Mapa','imageFormat':'png'})
            socket.close.assert_called_once()

    def test_missing_source_closes_connection(self):
        with patch('websocket.create_connection') as connect:
            socket=connect.return_value
            socket.recv.side_effect=[json.dumps(m) for m in [{'op':0,'d':{}},{'op':2,'d':{}},{'op':7,'d':{'requestStatus':{'result':False}}}]]
            with self.assertRaisesRegex(RuntimeError,'PanelDatos'):capture_scene()
            socket.close.assert_called_once()
