import json
import tempfile
import unittest
from pathlib import Path

import numpy as np
from PIL import Image

from zone_signature_index import ZoneIndex, build_zone_index
from zone_wide_locator import (
    GRID_SIZE,
    HALF,
    WideCalibration,
    WideKnownPositionOptimizer,
    WideZoneLocator,
    sample_wide_histograms,
)


class WideZoneLocatorTests(unittest.TestCase):
    def _fixture(self):
        temporary = tempfile.TemporaryDirectory()
        root = Path(temporary.name)
        floor = root / 'targuna' / 'floors' / '07'
        floor.mkdir(parents=True)
        palette = np.array([
            [0, 204, 0],
            [153, 153, 153],
            [255, 51, 0],
            [51, 102, 153],
            [255, 255, 0],
        ], dtype=np.uint8)
        rng = np.random.default_rng(91)
        classes = rng.integers(0, len(palette), size=(55, 60), dtype=np.uint8)
        rgb = palette[classes]
        Image.fromarray(rgb, 'RGB').save(floor / 'map.png')
        zone = {'id': 'targuna', 'bbox': [31920, 31850, 31979, 31904]}
        (root / 'targuna' / 'zone.json').write_text(json.dumps(zone), encoding='utf-8')
        build_zone_index(floor, palette_limit=16)
        index = ZoneIndex.load(floor, build_if_missing=False)
        return temporary, floor, palette, classes, index

    def _render(self, classes, palette, local_x, local_y, pitch=12):
        patch = classes[
            local_y-HALF:local_y+HALF+1,
            local_x-HALF:local_x+HALF+1,
        ]
        image = np.zeros((GRID_SIZE*pitch, GRID_SIZE*pitch, 3), dtype=np.uint8)
        for gy in range(GRID_SIZE):
            for gx in range(GRID_SIZE):
                color = palette[int(patch[gy, gx])]
                y0, y1 = gy*pitch, (gy+1)*pitch
                x0, x1 = gx*pitch, (gx+1)*pitch
                image[y0:y1, x0:x1] = color
                image[y0:y0+1, x0:x1] = palette[(int(patch[gy, gx])+1) % len(palette)]
        return Image.fromarray(image, 'RGB')

    def test_full_27x27_locator_finds_known_position(self):
        temporary, floor, palette, classes, index = self._fixture()
        try:
            local_x, local_y = 31, 29
            image = self._render(classes, palette, local_x, local_y, pitch=12)
            calibration = WideCalibration(
                center_x=13.5*12,
                center_y=13.5*12,
                tile_width=12,
                tile_height=12,
                patch_fraction=.45,
            )
            locator = WideZoneLocator(index, floor)
            hist = sample_wide_histograms(image, calibration, index.palette)
            position, score, gap, top = locator.locate(hist, top_k=5)
            expected = (31920+local_x, 31850+local_y)
            self.assertEqual(position, expected)
            self.assertGreater(score, .80)
            self.assertEqual(top[0]['position'], [expected[0], expected[1]])
            self.assertGreaterEqual(gap, 0.0)
            self.assertEqual(locator.compared_tiles, GRID_SIZE*GRID_SIZE-25)
        finally:
            temporary.cleanup()

    def test_optimizer_improves_offset_geometry(self):
        temporary, floor, palette, classes, index = self._fixture()
        try:
            local_x, local_y = 31, 29
            image = self._render(classes, palette, local_x, local_y, pitch=12)
            locator = WideZoneLocator(index, floor)
            known = (31920+local_x, 31850+local_y)
            initial = WideCalibration(
                center_x=13.5*12 + 4,
                center_y=13.5*12 - 3,
                tile_width=11.0,
                tile_height=13.0,
                patch_fraction=.38,
            )
            optimizer = WideKnownPositionOptimizer(image, locator, known)
            before = optimizer.score(initial)
            result = optimizer.optimize(initial)
            self.assertGreater(result['best_score'], before)
        finally:
            temporary.cleanup()


if __name__ == '__main__':
    unittest.main()
