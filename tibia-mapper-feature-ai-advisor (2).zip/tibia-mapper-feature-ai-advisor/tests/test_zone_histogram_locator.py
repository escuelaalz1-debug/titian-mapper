import json
import tempfile
import unittest
from pathlib import Path

import numpy as np
from PIL import Image

from zone_histogram_locator import (
    HistogramCalibration,
    HistogramZoneLocator,
    KnownPositionCalibrationOptimizer,
    sample_histogram_grid,
)
from zone_signature_index import HALF, ZoneIndex, build_zone_index, quantize_to_palette


class HistogramZoneLocatorTests(unittest.TestCase):
    def _fixture(self):
        temporary = tempfile.TemporaryDirectory()
        root = Path(temporary.name)
        floor = root / 'targuna' / 'floors' / '07'
        floor.mkdir(parents=True)
        palette = np.array([
            [0, 220, 0],
            [150, 150, 150],
            [245, 50, 20],
            [55, 110, 170],
            [245, 225, 30],
        ], dtype=np.uint8)
        rng = np.random.default_rng(42)
        classes = rng.integers(0, len(palette), size=(40, 45), dtype=np.uint8)
        rgb = palette[classes]
        Image.fromarray(rgb, 'RGB').save(floor / 'map.png')
        zone = {'id': 'targuna', 'bbox': [31920, 31870, 31964, 31909]}
        (root / 'targuna' / 'zone.json').write_text(json.dumps(zone), encoding='utf-8')
        build_zone_index(floor, palette_limit=16)
        return temporary, floor, palette, classes

    def test_quantize_uses_non_overflowing_distance(self):
        palette = np.array([[0, 0, 0], [255, 255, 255]], dtype=np.uint8)
        rgb = np.array([[[250, 250, 250], [5, 5, 5]]], dtype=np.uint8)
        result = quantize_to_palette(rgb, palette)
        self.assertEqual(result.tolist(), [[1, 0]])

    def test_histogram_locator_finds_rendered_known_position(self):
        temporary, floor, palette, classes = self._fixture()
        try:
            index = ZoneIndex.load(floor, build_if_missing=False)
            local_x, local_y = 22, 20
            scale_x, scale_y = 14, 16
            rendered = np.zeros((13 * scale_y, 13 * scale_x, 3), dtype=np.uint8)
            patch_classes = classes[local_y-HALF:local_y+HALF+1, local_x-HALF:local_x+HALF+1]
            for gy in range(13):
                for gx in range(13):
                    color = palette[int(patch_classes[gy, gx])]
                    y0, y1 = gy * scale_y, (gy + 1) * scale_y
                    x0, x1 = gx * scale_x, (gx + 1) * scale_x
                    rendered[y0:y1, x0:x1] = color
                    rendered[y0:y0+2, x0:x1] = palette[(int(patch_classes[gy, gx]) + 1) % len(palette)]
            image = Image.fromarray(rendered, 'RGB')
            calibration = HistogramCalibration(
                center_x=6.5 * scale_x,
                center_y=6.5 * scale_y,
                tile_width=scale_x,
                tile_height=scale_y,
            )
            hist = sample_histogram_grid(image, calibration, index.palette)
            locator = HistogramZoneLocator(index)
            position, score, gap, top = locator.locate(hist, top_k=3)
            expected = (31920 + local_x, 31870 + local_y)
            self.assertEqual(position, expected)
            self.assertGreater(score, .80)
            self.assertEqual(top[0]['position'], [expected[0], expected[1]])
            self.assertGreaterEqual(gap, 0.0)
        finally:
            temporary.cleanup()

    def test_optimizer_improves_shifted_geometry_for_known_position(self):
        temporary, floor, palette, classes = self._fixture()
        try:
            index = ZoneIndex.load(floor, build_if_missing=False)
            locator = HistogramZoneLocator(index)
            local_x, local_y = 22, 20
            known = (31920 + local_x, 31870 + local_y)
            scale_x, scale_y = 14, 16
            width, height = 230, 250
            rendered = np.zeros((height, width, 3), dtype=np.uint8)
            patch_classes = classes[local_y-HALF:local_y+HALF+1, local_x-HALF:local_x+HALF+1]
            true_center_x, true_center_y = 115.0, 125.0

            for gy in range(-HALF, HALF + 1):
                for gx in range(-HALF, HALF + 1):
                    color = palette[int(patch_classes[gy + HALF, gx + HALF])]
                    cx = true_center_x + gx * scale_x
                    cy = true_center_y + gy * scale_y
                    x0, x1 = int(cx - scale_x / 2), int(cx + scale_x / 2)
                    y0, y1 = int(cy - scale_y / 2), int(cy + scale_y / 2)
                    rendered[y0:y1, x0:x1] = color

            image = Image.fromarray(rendered, 'RGB')
            initial = HistogramCalibration(
                center_x=true_center_x + 8,
                center_y=true_center_y - 7,
                tile_width=scale_x + 2,
                tile_height=scale_y - 2,
            )
            initial_hist = sample_histogram_grid(image, initial, index.palette)
            initial_score = locator.score_position(initial_hist, known)

            optimizer = KnownPositionCalibrationOptimizer(image, locator, known)
            result = optimizer.optimize(initial)
            optimized = result['best']
            optimized_hist = sample_histogram_grid(image, optimized, index.palette)
            optimized_score = locator.score_position(optimized_hist, known)

            self.assertGreater(optimized_score, initial_score + .20)
            self.assertGreater(optimized_score, .75)
            self.assertLess(abs(optimized.center_x - true_center_x), 4.0)
            self.assertLess(abs(optimized.center_y - true_center_y), 4.0)
            self.assertLess(abs(optimized.tile_width - scale_x), 2.0)
            self.assertLess(abs(optimized.tile_height - scale_y), 2.0)
        finally:
            temporary.cleanup()


if __name__ == '__main__':
    unittest.main()
