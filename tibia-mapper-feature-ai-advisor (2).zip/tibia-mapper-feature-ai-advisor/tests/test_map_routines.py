import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from flask import Flask
import map_routine_store as store
from map_routes import register_map_routes


class MapRoutineTests(unittest.TestCase):
    def test_create_reload_and_validate(self):
        zones = [{'id': 'city', 'bbox': [100, 200, 110, 210], 'floors': [7, 8]}]
        with tempfile.TemporaryDirectory() as folder, patch.object(store, 'MAP_ROUTINES_DIR', Path(folder)), patch('map_routes.list_map_zones', return_value=zones):
            app = Flask(__name__)
            register_map_routes(app)
            client = app.test_client()
            payload = {'name': 'Ruta', 'points': [{'x': 101, 'y': 202, 'z': 7, 'zone_id': 'city'}, {'x': 103, 'y': 204, 'z': 8, 'zone_id': 'city'}]}
            result = client.post('/api/map/routines', json=payload)
            self.assertEqual(result.status_code, 201)
            routines = client.get('/api/map/routines').json['routines']
            self.assertEqual([{k:p[k] for k in ('x','y','z','zone_id')} for p in routines[0]['points']], payload['points'])
            self.assertEqual(routines[0]['points'][1]['selection_mode'], 'floor_transition')
            self.assertEqual(routines[0]['coordinate_system'], 'tibia_world')
            for invalid in ({}, {'name':'Ruta', 'points':[]}, {'name':'Ruta', 'points':[{'x':999,'y':202,'z':7,'zone_id':'city'}]}, {'name':'Ruta', 'points':[{'x':101,'y':202,'z':9,'zone_id':'city'}]}):
                self.assertEqual(client.post('/api/map/routines', json=invalid).status_code, 400)
            self.assertEqual(len(client.get('/api/map/routines').json['routines']), 1)
