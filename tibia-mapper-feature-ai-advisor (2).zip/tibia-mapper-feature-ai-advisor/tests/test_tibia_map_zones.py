import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from PIL import Image
from tibia_map_zones import organize_maps, write_json
import tibia_map_service as service


class ZoneTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.source = self.root / "source"
        self.output = self.root / "zones"
        self.catalog = self.root / "catalog.json"
        write_json(self.source / "bounds.json", {"xMin": 100, "yMin": 200, "width": 4, "height": 3, "zMin": 7, "zMax": 7})
        write_json(self.source / "markers.json", [
            {"x": 101, "y": 201, "z": 7, "description": "inside"},
            {"x": 103, "y": 202, "z": 7, "description": "edge"},
            {"x": 100, "y": 200, "z": 7, "description": "outside"},
            {"x": 101, "y": 201, "z": 8, "description": "other floor"}])
        write_json(self.catalog, {"zones": [{"area": "Thais", "subarea": "City", "id": "thais-city", "bbox": [101, 201, 105, 205]}]})
        image = Image.new("RGB", (4, 3))
        image.putpixel((1, 1), (23, 45, 67))
        image.putpixel((3, 2), (255, 255, 0))
        for layer in ("map", "pathfinding"):
            image.save(self.source / f"floor-07-{layer}.png")

    def test_crops_preserve_pixels_coordinates_markers_and_api(self):
        index = organize_maps(self.source, self.output, self.catalog)
        self.assertEqual(index["zones"][0]["bbox"], [101, 201, 103, 202])
        floor = self.output / "thais/thais-city/floors/07"
        for layer in ("map", "pathfinding"):
            with Image.open(floor / f"{layer}.png") as image:
                self.assertEqual(image.size, (3, 2))
                self.assertEqual(image.getpixel((0, 0)), (23, 45, 67))
                self.assertEqual(image.getpixel((2, 1)), (255, 255, 0))
        markers = json.loads((floor / "markers.json").read_text())
        self.assertEqual([m["description"] for m in markers], ["inside", "edge"])
        with patch.object(service, "MAP_ZONES_ROOT", self.output):
            self.assertEqual(service.position_zones(103, 202, 7)[0]["pixel"], {"x": 2, "y": 1})
            self.assertEqual(service.position_zones(103, 202, 8), [])
            from flask import Flask
            from map_routes import register_map_routes
            app = Flask(__name__)
            register_map_routes(app)
            client = app.test_client()
            self.assertEqual(len(client.get('/api/map/zones?area=THAIS').json['zones']), 1)
            self.assertEqual(client.get('/api/map/zones?area=Venore').json['zones'], [])
            with client.get('/api/map/zones/thais-city/floors/7/map') as response:
                self.assertEqual(response.mimetype, 'image/png')
            with client.get('/api/map/zones/thais-city/floors/7/markers') as response:
                self.assertEqual(response.json, markers)
            for url in ('/api/map/zones/missing/floors/7/map',
                        '/api/map/zones/thais-city/floors/8/map',
                        '/api/map/zones/thais-city/floors/7/secret'):
                self.assertEqual(client.get(url).status_code, 404)

    def test_failed_rebuild_preserves_previous_output(self):
        organize_maps(self.source, self.output, self.catalog)
        original = (self.output / "index.json").read_bytes()
        (self.source / "floor-07-map.png").unlink()
        with self.assertRaises(FileNotFoundError):
            organize_maps(self.source, self.output, self.catalog)
        self.assertEqual((self.output / "index.json").read_bytes(), original)

    def test_upstream_path_filename(self):
        (self.source / "floor-07-pathfinding.png").rename(self.source / "floor-07-path.png")
        organize_maps(self.source, self.output, self.catalog)
        with patch.object(service, "MAP_DATA_ROOT", self.source):
            self.assertEqual(service._floor_pathfinding_path(7).name, "floor-07-path.png")

    def test_rebuild_removes_stale_files(self):
        organize_maps(self.source, self.output, self.catalog)
        (self.output / "stale.txt").write_text("old")
        organize_maps(self.source, self.output, self.catalog)
        self.assertFalse((self.output / "stale.txt").exists())

    def test_originals_cannot_be_replaced(self):
        with self.assertRaises(ValueError):
            organize_maps(self.source, self.source, self.catalog)

    def test_missing_cache_keeps_legacy_lookups_available(self):
        with patch.object(service, "MAP_ZONES_ROOT", self.output):
            self.assertEqual(service.list_map_zones(), [])


if __name__ == "__main__":
    unittest.main()
