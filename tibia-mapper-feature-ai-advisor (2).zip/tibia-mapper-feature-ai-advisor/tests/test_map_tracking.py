import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import numpy as np
from PIL import Image, ImageDraw

import map_tracking as tracking


class TrackingTests(unittest.TestCase):
    def test_detour_and_unreachable(self):
        grid = np.ones((7, 7), dtype=bool)
        grid[:6, 3] = False
        path = tracking.shortest_path(grid, (1, 1), [(5, 1)])
        self.assertIn((3, 6), path)
        self.assertTrue(all(grid[y, x] for x, y in path))
        grid[6, 3] = False
        with self.assertRaises(ValueError):
            tracking.shortest_path(grid, (1, 1), [(5, 1)])

    def test_localization_and_ambiguous_matches(self):
        world = np.random.default_rng(7).integers(20, 240, (100, 100, 3), dtype=np.uint8)
        template = world[20:41, 30:51].copy()
        position, score = tracking.locate(world, template)
        self.assertEqual(position, (40, 30))
        self.assertGreater(score, .99)
        world[60:81, 60:81] = template
        with self.assertRaises(ValueError):
            tracking.locate(world, template)

    def test_minimap_grid_is_fixed_13x13(self):
        image = Image.new('RGB', (130, 130), (10, 20, 30))
        grid = tracking.minimap_grid(image)
        self.assertEqual(grid.shape, (13, 13, 3))
        self.assertEqual(tuple(grid[0, 0]), (10, 20, 30))

    def test_calibration_detects_white_cross_and_tile_pitch(self):
        image = Image.new('RGB', (130, 130), (30, 150, 30))
        draw = ImageDraw.Draw(image)
        draw.rectangle((61, 54, 68, 75), fill=(245, 245, 245))
        draw.rectangle((54, 61, 75, 68), fill=(245, 245, 245))
        calibration = tracking.detect_minimap_calibration(image)
        self.assertTrue(calibration['cross_detected'])
        self.assertAlmostEqual(calibration['center_x'], 64.5, delta=1.0)
        self.assertAlmostEqual(calibration['center_y'], 64.5, delta=1.0)
        self.assertAlmostEqual(calibration['tile_width'], 10.0, delta=.5)
        self.assertAlmostEqual(calibration['tile_height'], 10.0, delta=.5)
        grid = tracking.sample_minimap_grid(image, calibration)
        self.assertEqual(grid.shape, (13, 13, 3))

    def test_relative_move_detects_east_and_ignores_center(self):
        rng = np.random.default_rng(11)
        previous = rng.integers(0, 255, (13, 13, 3), dtype=np.uint8)
        current = np.empty_like(previous)
        current[:, :12] = previous[:, 1:]
        current[:, 12] = rng.integers(0, 255, (13, 3), dtype=np.uint8)
        previous[4:9, 4:9] = 255
        current[4:9, 4:9] = 255
        delta, score, gap = tracking.detect_relative_move(previous, current, max_step=3)
        self.assertEqual(delta, (1, 0))
        self.assertGreater(score, .8)
        self.assertGreaterEqual(gap, 0)

    def test_three_tile_jump_with_observed_weak_gap_is_rejected(self):
        previous = np.zeros((13, 13, 3), dtype=np.uint8)
        current = previous.copy()

        def fake_score(_previous, _current, dx, dy):
            if (dx, dy) == (0, -3):
                return .84
            if (dx, dy) == (0, -2):
                return .822
            return .40

        with patch.object(tracking, '_relative_score', side_effect=fake_score):
            with self.assertRaisesRegex(ValueError, '3 cuadro'):
                tracking.detect_relative_move(previous, current, max_step=3)

    def test_coarse_color_score_tolerates_small_rgb_changes(self):
        a = np.zeros((13, 13, 3), dtype=np.uint8)
        b = np.zeros((13, 13, 3), dtype=np.uint8)
        a[:, :] = (0, 210, 0)
        b[:, :] = (20, 190, 20)
        self.assertTrue(np.all(tracking._coarse_colors(a) == tracking._coarse_colors(b)))
        self.assertGreater(tracking._patch_score(a, b), .8)

    def test_localize_near_finds_absolute_candidate(self):
        rng = np.random.default_rng(13)
        world = rng.integers(0, 255, (60, 60, 3), dtype=np.uint8)
        walkable = np.ones((60, 60), dtype=bool)
        actual = (31, 29)
        half = tracking.MINIMAP_TILES // 2
        grid = world[actual[1]-half:actual[1]+half+1, actual[0]-half:actual[0]+half+1].copy()
        position, score, gap, candidates = tracking.localize_near(
            world,
            walkable,
            grid,
            center=(30, 30),
            expected=actual,
            radius=3,
        )
        self.assertEqual(position, actual)
        self.assertGreater(score, .95)
        self.assertGreaterEqual(gap, 0)
        self.assertEqual(candidates[0]['position'], [actual[0], actual[1]])

    def test_tracker_uses_absolute_localizer_not_relative_delta_as_truth(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            data = root / 'data'
            data.mkdir()
            Image.new('RGB', (50, 50), (90, 90, 90)).save(data / 'floor-07-path.png')
            Image.new('RGB', (50, 50), (90, 120, 90)).save(data / 'floor-07-map.png')
            with patch.object(tracking, 'RUNTIME_ROOT', root), \
                 patch.object(tracking.maps, 'MAP_DATA_ROOT', data), \
                 patch.object(tracking.maps, '_load_bounds', return_value={'xMin': 100, 'yMin': 200}):
                tracker = tracking.Tracker(
                    {'points': [{'x': 110, 'y': 210, 'z': 7}, {'x': 120, 'y': 210, 'z': 7}]},
                    {'x': 0, 'y': 0, 'width': 21, 'height': 21, 'initial_x': 110, 'initial_y': 210},
                )
                frame = Image.new('RGB', (30, 30), (90, 120, 90))
                tracker.sample(frame)
                top = [
                    {'position': [11, 10], 'map_score': .91, 'combined': .90},
                    {'position': [10, 10], 'map_score': .80, 'combined': .79},
                ]
                with patch.object(tracking, 'detect_relative_move', return_value=((0, -3), .99, .30)), \
                     patch.object(tracking, 'localize_near', return_value=((11, 10), .91, .11, top)):
                    result = tracker.sample(frame)
                self.assertEqual(result['delta'], [1, 0])
                self.assertEqual(result['relative_delta'], [0, -3])
                self.assertEqual(result['position'], [111, 210])
                self.assertEqual(tracker.last, (11, 10))

    def test_tracker_advances_visual_reference_even_when_map_localization_fails(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            data = root / 'data'
            data.mkdir()
            Image.new('RGB', (50, 50), (90, 90, 90)).save(data / 'floor-07-path.png')
            Image.new('RGB', (50, 50), (90, 120, 90)).save(data / 'floor-07-map.png')
            with patch.object(tracking, 'RUNTIME_ROOT', root), \
                 patch.object(tracking.maps, 'MAP_DATA_ROOT', data), \
                 patch.object(tracking.maps, '_load_bounds', return_value={'xMin': 100, 'yMin': 200}):
                tracker = tracking.Tracker(
                    {'points': [{'x': 110, 'y': 210, 'z': 7}, {'x': 120, 'y': 210, 'z': 7}]},
                    {'x': 0, 'y': 0, 'width': 21, 'height': 21, 'initial_x': 110, 'initial_y': 210},
                )
                first_frame = Image.new('RGB', (30, 30), (90, 120, 90))
                second_frame = Image.new('RGB', (30, 30), (100, 130, 100))
                tracker.sample(first_frame)
                old_grid = tracker.previous_grid.copy()
                with patch.object(tracking, 'detect_relative_move', side_effect=ValueError('ambiguo')), \
                     patch.object(tracking, 'localize_near', side_effect=ValueError('sin candidato')):
                    result = tracker.sample(second_frame)
                self.assertTrue(result['position_stale'])
                self.assertEqual(result['position'], [110, 210])
                self.assertEqual(tracker.last, (10, 10))
                self.assertFalse(np.array_equal(tracker.previous_grid, old_grid))
