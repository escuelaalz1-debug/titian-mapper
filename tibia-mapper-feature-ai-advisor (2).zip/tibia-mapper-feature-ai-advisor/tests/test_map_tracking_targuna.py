import unittest
from pathlib import Path

from map_tracking_targuna import TRIAL_WIDE_FLOORS, targuna_floor_dir


class TargunaMultiFloorTrackerTests(unittest.TestCase):
    def test_floor_08_is_enabled_for_wide_trial(self):
        self.assertIn(8, TRIAL_WIDE_FLOORS)

    def test_floor_dir_uses_two_digit_floor_name(self):
        root = Path('runtime-root')
        expected = root / 'data' / 'tibia-map-zones' / 'thais' / 'targuna' / 'floors' / '08'
        self.assertEqual(targuna_floor_dir(root, 8), expected)

    def test_floor_dir_rejects_invalid_floor(self):
        with self.assertRaises(ValueError):
            targuna_floor_dir(Path('runtime-root'), 16)


if __name__ == '__main__':
    unittest.main()
