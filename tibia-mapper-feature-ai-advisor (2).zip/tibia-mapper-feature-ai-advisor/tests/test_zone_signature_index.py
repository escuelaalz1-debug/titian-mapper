import json
import tempfile
import unittest
from pathlib import Path

import numpy as np
from PIL import Image

from zone_signature_index import HALF, WINDOW, ZoneIndex, build_zone_index


class ZoneSignatureIndexTests(unittest.TestCase):
    def test_build_and_locate_known_patch(self):
        rng = np.random.default_rng(123)
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            floor = root / "targuna" / "floors" / "07"
            floor.mkdir(parents=True)

            palette = np.array([
                [0, 220, 0],
                [150, 150, 150],
                [245, 50, 20],
                [40, 100, 180],
                [240, 220, 40],
            ], dtype=np.uint8)
            classes = rng.integers(0, len(palette), size=(40, 45), dtype=np.uint8)
            rgb = palette[classes]
            Image.fromarray(rgb, "RGB").save(floor / "map.png")

            zone = {"id": "targuna", "bbox": [31920, 31870, 31964, 31909]}
            (root / "targuna" / "zone.json").write_text(json.dumps(zone), encoding="utf-8")

            metadata = build_zone_index(floor, block_size=8, palette_limit=16)
            self.assertEqual(metadata["width"], 45)
            self.assertEqual(metadata["height"], 40)
            self.assertTrue((floor / "locator-index.npz").is_file())
            self.assertTrue((floor / "locator-regions.png").is_file())

            index = ZoneIndex.load(floor, build_if_missing=False)
            local_x, local_y = 21, 19
            patch = rgb[local_y-HALF:local_y+HALF+1, local_x-HALF:local_x+HALF+1]
            self.assertEqual(patch.shape, (WINDOW, WINDOW, 3))

            position, score, gap, top = index.locate(patch, top_k=5, max_distance=None)
            self.assertEqual(position, (31920 + local_x, 31870 + local_y))
            self.assertGreater(score, 0.99)
            self.assertGreaterEqual(gap, 0.0)
            self.assertEqual(top[0]["position"], [position[0], position[1]])


if __name__ == "__main__":
    unittest.main()
