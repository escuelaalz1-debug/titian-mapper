from __future__ import annotations


DIRECTION_KEYS = {
    'Norte': 'up',
    'Sur': 'down',
    'Oeste': 'left',
    'Este': 'right',
}


def direction_to_key(direction: str) -> str:
    """Translate tracker cardinal directions to PyAutoGUI arrow-key names."""
    normalized = str(direction or '').strip()
    try:
        return DIRECTION_KEYS[normalized]
    except KeyError as exc:
        raise ValueError(f'Dirección inválida: {normalized!r}') from exc


def press_direction(direction: str) -> str:
    """Press one real arrow key in the currently focused Windows application."""
    key = direction_to_key(direction)
    import pyautogui

    pyautogui.press(key)
    return key
