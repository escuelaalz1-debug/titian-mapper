# Tibia Mapper

Aplicación local en Python + Flask para administrar rutinas, checkpoints visuales, eventos, Battle y configuración.

## Ejecutar en desarrollo

```powershell
pip install -r requirements.txt
python app.py
```

Luego abre `http://127.0.0.1:5000`.

## EXE portable para otro PC

El proyecto queda preparado para generar una distribución Windows x64 que **no necesita Python en el PC destino**.

La distribución es de tipo `onedir`: `tibia-mapper.exe` debe viajar junto con los archivos y carpetas generados por PyInstaller. No copies solamente el `.exe`; copia/descomprime el paquete completo.

### Opción 1: compilar en tu PC

En Windows:

```powershell
git pull
build_exe.bat
```

Al terminar tendrás:

```text
dist\tibia-mapper\
dist\tibia-mapper-windows-x64.zip
```

El ZIP es el archivo recomendado para pasar al otro PC.

### Opción 2: descargar el EXE generado por GitHub

El repositorio incluye el workflow:

```text
.github/workflows/build-windows-exe.yml
```

Cada `push` a `main` genera automáticamente el paquete Windows.

En GitHub:

1. Abre la pestaña **Actions**.
2. Entra a **Build Windows EXE**.
3. Abre la ejecución más reciente que terminó correctamente.
4. En **Artifacts**, descarga `tibia-mapper-windows-x64`.
5. Descomprime el ZIP descargado y luego descomprime `tibia-mapper-windows-x64.zip` si GitHub lo entrega dentro del artifact.

También puedes ejecutar el workflow manualmente con **Run workflow**.

## Pasarlo al otro PC

Copia o descomprime **toda** la carpeta portable y ejecuta:

```text
tibia-mapper.exe
```

El navegador se abre automáticamente en:

```text
http://127.0.0.1:5000
```

Los datos editables se guardan junto al ejecutable:

```text
routines\
events\
checkpoints\
battle_targets\
battle_targets\images\
data\
logs\
settings.json
```

Por eso puedes reemplazar los binarios de una versión futura conservando esas carpetas/archivos para mantener la configuración, rutinas, eventos y referencias Battle.

## Capturas NVIDIA en el PC destino

La aplicación no instala NVIDIA ni GeForce/NVIDIA App. El PC destino debe tener funcionando la captura de NVIDIA con `Alt+F1`, igual que el equipo de desarrollo.

La aplicación espera las capturas en la carpeta equivalente a:

```text
C:\Users\<usuario>\Videos\Desktop
```

Si NVIDIA guarda las capturas en otra ubicación, habrá que ajustar `capture_utils.py`.

## Archivos de empaquetado

- `tibia-mapper.spec`: configuración PyInstaller; incluye `templates/` y `static/`.
- `build_exe.bat`: compila y además crea `tibia-mapper-windows-x64.zip`.
- `.github/workflows/build-windows-exe.yml`: genera automáticamente el ZIP portable en Windows.
- `launcher.py`: inicia Flask y abre el navegador.
- `app_paths.py`: mantiene los datos persistentes junto al ejecutable cuando está empaquetado.

## Estructura principal

- `app.py`: servidor Flask y API.
- `launcher.py`: entrada para el EXE.
- `app_paths.py`: rutas compatibles con Python y PyInstaller.
- `routine_store.py`: persistencia de rutinas.
- `event_store.py`: persistencia de eventos.
- `battle_store.py`: referencias visuales de Battle.
- `battle_monitor.py`: detección y estado Battle.
- `checkpoint_store.py`: checkpoints visuales.
- `capture_utils.py`: capturas NVIDIA.
- `recorder.py`: grabación F11/F12.
- `mapper_store.py`: SQLite.
- `session_log.py`: logs.
- `templates/`: frontend HTML.
- `static/`: estilos y recursos web.
# Mapas por ciudades y zonas

## Seguimiento pasivo y regreso

La captura del seguimiento ahora se obtiene **directamente de la escena OBS
`PanelDatos`**, mediante obs-websocket 5 (`GetSourceScreenshot`), sin DXGI ni
captura del escritorio. En OBS activa **Herramientas → Ajustes del servidor
WebSocket** y rellena el puerto (normalmente 4455) y la contraseña en la vista.
Pulsa **Capturar escena OBS** antes de iniciar. La contraseña se conserva solo
en memoria. Vuelve a seleccionar el minimapa: las coordenadas pertenecen ahora
a la imagen de la escena, no al monitor/proyector. Esto reemplaza la fuente
DXGI descrita en las instrucciones anteriores. Los demás monitores de la
aplicación conservan su captura existente.

En **Mapas por zonas → Seguimiento y regreso**, elige una rutina guardada de
un solo piso. Pulsa **Capturar OBS/DXGI** y marca dos esquinas del interior del
minimapa. Mantén al personaje centrado y ajusta los píxeles por cuadro según
el zoom del cliente y la escala de OBS. Inicia el seguimiento y mueve tú al
personaje. La captura usa el monitor DXGI configurado; no mueve ni pulsa nada.

El recorrido de referencia se calcula sobre los datos transitables locales,
con movimientos cardinales. Se permiten dos cuadros de margen y se confirman
los estados con dos observaciones. El visor muestra ruta, recorrido observado,
posición y regreso a la parte pendiente. Los eventos `DESVIO`, `REGRESO`,
`CAMINO_REGRESO` y `POSICION_DESCONOCIDA` se guardan en
`logs/map-tracking-*.jsonl`. Las instrucciones de regreso incluyen direcciones
y coordenadas; pueden repetirse a medida que cambias de posición.

La detección es experimental: exige coincidencia visual clara y separada de
otras ubicaciones. Si no la encuentra, deja de indicar posición y regreso.
Esta versión requiere mantener el mismo piso; detén y recalibra al cambiarlo.
Los caminos no contemplan monstruos, puertas cerradas ni otros obstáculos
dinámicos. Hay un solo seguimiento activo por aplicación. El muestreo ocurre
cada dos segundos después de terminar la consulta anterior, mientras la vista
permanece abierta (el navegador puede ralentizar pestañas en segundo plano).

En la rama `feature/ai-advisor`, el actualizador también genera carpetas por
región, subzona y piso:

```powershell
.\scripts\update_tibiamaps.ps1
```

Si ya descargaste los mapas, puedes reorganizarlos sin conexión:

```powershell
python scripts/organize_tibiamaps.py
```

Requiere las dependencias de `requirements.txt`, incluido Pillow.
La estructura generada es:

```text
data/
  tibia-map-data/data/           # Originales descargados de TibiaMaps
  tibia-map-zones/
    index.json
    thais/
      thais-city/
        zone.json
        floors/
          07/
            map.png
            pathfinding.png
            markers.json
```

El catálogo `config/tibia_map_zones.json` contiene 21 regiones y 192 subzonas,
con nombres y rectángulos publicados por
[TibiaMaps](https://tibiamaps.io/_json/areas.json), consultados el 7 de septiembre
de 2026. Se puede editar para añadir o ajustar zonas y volver a generar.
Los límites `bbox` son `[x_min, y_min, x_max, y_max]`, inclusivos.
Cada zona se recorta al tamaño real de las imágenes y contiene los pisos
indicados por `bounds.json`. Las coordenadas de los marcadores siguen siendo
coordenadas globales de Tibia.

Son recortes rectangulares: pueden solaparse e incluir terreno vecino. El
nombre de una carpeta no implica que todos sus píxeles o pisos pertenezcan a
esa región de la Cyclopedia. El mapa completo conserva las áreas no incluidas
en el catálogo. Los originales nunca se mueven; las carpetas generadas son
caché ignorada por Git. No guardes archivos propios dentro de esa caché:
una generación completa la reemplaza; si falla la generación, conserva la
versión anterior. Hace falta espacio para ambas versiones durante el proceso.

Con `python app_ai.py`:

Abre **Mapas por zonas** desde la navegación principal, o entra en `/maps`.
En **Crear rutina**, escribe un nombre, activa **Marcar puntos en el mapa** y
haz clic para trazar el recorrido. Puedes cambiar de zona/piso, quitar puntos,
deshacer y guardar. La lista de rutinas guardadas permite reabrirlas; guardar
crea una nueva copia. Se almacenan en `routines/map/` como posiciones del mundo
de Tibia, separadas de las rutinas de pantalla. Son rutas de referencia: no
calculan caminos transitables ni ejecutan movimientos en el juego.
Elige región, zona y piso para ver el mapa o los datos de movimiento, ampliar
la imagen y consultar coordenadas y marcadores. «Actualizar zonas» vuelve a
leer las carpetas generadas; no descarga ni regenera mapas.

- `GET /api/map/zones`: lista las zonas generadas y sus carpetas relativas.
- `GET /api/map/zones?area=Thais`: filtra por región.
- `GET /api/map/position?x=32369&y=32241&z=7`: incluye `zones` con los
  recortes que contienen la posición y la coordenada del píxel dentro de cada uno.
- `GET /api/map/status`: indica si existe la caché organizada y dónde está.

Las consultas existentes siguen funcionando sin la caché de zonas. Se aceptan
tanto los archivos originales `floor-XX-path.png` como el nombre anterior
`floor-XX-pathfinding.png`.
