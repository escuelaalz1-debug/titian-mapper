"""Run from any directory: python scripts/organize_tibiamaps.py."""
from pathlib import Path
import argparse
import sys

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from tibia_map_zones import organize_maps


def main():
    parser = argparse.ArgumentParser(description="Separar TibiaMaps por regiones, zonas y pisos.")
    parser.add_argument("--source", type=Path, default=ROOT / "data/tibia-map-data/data")
    parser.add_argument("--output", type=Path, default=ROOT / "data/tibia-map-zones")
    parser.add_argument("--catalog", type=Path, default=ROOT / "config/tibia_map_zones.json")
    args = parser.parse_args()
    index = organize_maps(args.source, args.output, args.catalog)
    print(f"Listo: {len(index['zones'])} zonas en {args.output.resolve()}")


if __name__ == "__main__":
    main()
