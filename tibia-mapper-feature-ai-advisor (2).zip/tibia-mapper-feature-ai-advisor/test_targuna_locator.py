from __future__ import annotations

import argparse
import os
from pathlib import Path

from app_paths import RUNTIME_ROOT
from obs_scene_capture import capture_source
from zone_signature_index import ZoneIndex, build_zone_index, targuna_floor_07
from zone_wide_locator import (
    GRID_SIZE,
    WideCalibration,
    WideKnownPositionOptimizer,
    WideZoneLocator,
    default_wide_calibration,
    draw_wide_debug,
    sample_wide_histograms,
)

DEFAULT_CROP = {
    'x': 462,
    'y': 19,
    'width': 1008,
    'height': 1036,
}
DEFAULT_CENTER = (516.0, 517.0)
DEFAULT_KNOWN_POSITION = (31950, 31898)


def calibration_text(calibration: WideCalibration) -> str:
    return (
        f'centro=({calibration.center_x:.3f}, {calibration.center_y:.3f}) '
        f'pitch={calibration.tile_width:.3f}x{calibration.tile_height:.3f} '
        f'parche={calibration.patch_fraction:.0%}'
    )


def main() -> int:
    parser = argparse.ArgumentParser(
        description='Prueba Targuna piso 07 usando todas las posiciones visibles del minimapa (27x27).'
    )
    parser.add_argument('--source', default='Mapa', help='Nombre de la fuente OBS del minimapa.')
    parser.add_argument('--port', type=int, default=4455)
    parser.add_argument('--x', type=int, default=DEFAULT_CROP['x'])
    parser.add_argument('--y', type=int, default=DEFAULT_CROP['y'])
    parser.add_argument('--width', type=int, default=DEFAULT_CROP['width'])
    parser.add_argument('--height', type=int, default=DEFAULT_CROP['height'])
    parser.add_argument('--center-x', type=float, default=DEFAULT_CENTER[0])
    parser.add_argument('--center-y', type=float, default=DEFAULT_CENTER[1])
    parser.add_argument('--pitch-x', type=float)
    parser.add_argument('--pitch-y', type=float)
    parser.add_argument('--patch-fraction', type=float, default=.38)
    parser.add_argument('--known-x', type=int, default=DEFAULT_KNOWN_POSITION[0])
    parser.add_argument('--known-y', type=int, default=DEFAULT_KNOWN_POSITION[1])
    parser.add_argument('--top', type=int, default=10)
    parser.add_argument('--no-optimize', action='store_true')
    parser.add_argument(
        '--debug-before-image',
        type=Path,
        default=RUNTIME_ROOT / 'logs' / 'targuna-wide-before.png',
    )
    parser.add_argument(
        '--debug-after-image',
        type=Path,
        default=RUNTIME_ROOT / 'logs' / 'targuna-wide-after.png',
    )
    args = parser.parse_args()

    password = os.getenv('OBS_WEBSOCKET_PASSWORD', '')
    floor_dir = targuna_floor_07(RUNTIME_ROOT)
    metadata = build_zone_index(floor_dir)
    index = ZoneIndex.load(floor_dir, build_if_missing=False)
    locator = WideZoneLocator(index, floor_dir)

    image = capture_source(args.source, port=args.port, password=password)
    if args.x < 0 or args.y < 0 or args.width < GRID_SIZE or args.height < GRID_SIZE:
        raise ValueError('Recorte inválido.')
    if args.x + args.width > image.width or args.y + args.height > image.height:
        raise ValueError(
            f'El recorte ({args.x},{args.y},{args.width},{args.height}) sale de la captura OBS {image.width}x{image.height}.'
        )
    crop = image.crop((args.x, args.y, args.x + args.width, args.y + args.height))

    estimated = default_wide_calibration(crop, args.center_x, args.center_y)
    initial = WideCalibration(
        center_x=args.center_x,
        center_y=args.center_y,
        tile_width=float(args.pitch_x if args.pitch_x is not None else estimated.tile_width),
        tile_height=float(args.pitch_y if args.pitch_y is not None else estimated.tile_height),
        patch_fraction=float(args.patch_fraction),
    )
    known = (args.known_x, args.known_y)

    initial_hist = sample_wide_histograms(crop, initial, index.palette)
    initial_debug = locator.debug_known(initial_hist, known)
    draw_wide_debug(crop, initial, initial_debug, args.debug_before_image)

    if args.no_optimize:
        optimized = initial
        optimization = {'history': []}
    else:
        optimization = WideKnownPositionOptimizer(crop, locator, known).optimize(initial)
        optimized = optimization['best']

    hist_grid = sample_wide_histograms(crop, optimized, index.palette)
    known_debug = locator.debug_known(hist_grid, known)
    draw_wide_debug(crop, optimized, known_debug, args.debug_after_image)
    position, score, gap, candidates = locator.locate(hist_grid, top_k=args.top)

    known_rank = next(
        (number for number, candidate in enumerate(candidates, 1) if tuple(candidate['position']) == known),
        None,
    )
    if known_rank is None:
        all_position, all_score, _, all_candidates = locator.locate(hist_grid, top_k=len(locator.positions))
        known_rank = next(
            number for number, candidate in enumerate(all_candidates, 1) if tuple(candidate['position']) == known
        )

    print(f'Zona: {locator.floor_dir}')
    print(f'Índice de paleta reconstruido: versión {metadata["version"]}')
    print(f'Captura OBS: {image.width}x{image.height}')
    print(f'Recorte usado: x={args.x} y={args.y} width={args.width} height={args.height}')
    print(f'GRILLA LÓGICA: {GRID_SIZE}x{GRID_SIZE} = {GRID_SIZE*GRID_SIZE} posiciones visibles')
    print(f'Tiles comparados por candidato: {locator.compared_tiles} (centro 5x5 ignorado)')
    print(f'Posiciones globales candidatas en map.png: {len(locator.positions)}')
    print('Comparación: histograma de color por cada posición lógica contra todo Targuna piso 07')

    print('\nCALIBRACIÓN INICIAL 27x27')
    print(f'  {calibration_text(initial)}')
    print(
        f'  conocida: {known_debug["score"] if args.no_optimize else initial_debug["score"]:.1%} · '
        f'G/Y/R {initial_debug["good"]}/{initial_debug["medium"]}/{initial_debug["bad"]}'
    )

    if not args.no_optimize:
        print('\nETAPAS DEL OPTIMIZADOR 27x27')
        for stage in optimization['history']:
            print(f'  {stage["stage"]:<15} {stage["score"]:.1%} · {calibration_text(stage["calibration"])}')

    print('\nCALIBRACIÓN FINAL')
    print(f'  {calibration_text(optimized)}')
    print(
        f'  conocida: {known_debug["score"]:.1%} · '
        f'G/Y/R {known_debug["good"]}/{known_debug["medium"]}/{known_debug["bad"]}'
    )
    print(f'  mejora: {known_debug["score"] - initial_debug["score"]:+.1%}')
    print(f'DEBUG ANTES:   {args.debug_before_image}')
    print(f'DEBUG DESPUÉS: {args.debug_after_image}')

    print(f'\nPOSICIÓN CONOCIDA: {known[0]}, {known[1]} · score {known_debug["score"]:.1%} · ranking GLOBAL #{known_rank}')
    print(f'MEJOR POSICIÓN GLOBAL: {position[0]}, {position[1]} · score {score:.1%} · gap {gap:.4f}')
    print('TOP candidatos:')
    for number, candidate in enumerate(candidates, 1):
        x, y = candidate['position']
        marker = ' <= conocida' if (x, y) == known else ''
        print(f'  {number:02d}. {x}, {y} · score {candidate["score"]:.1%}{marker}')

    print('\nCONFUSIONES DOMINANTES EN LA POSICIÓN CONOCIDA')
    for pair, count in known_debug['confusion'][:12]:
        expected, observed = pair.split('->')
        expected_rgb = tuple(int(v) for v in index.palette[int(expected)])
        observed_rgb = tuple(int(v) for v in index.palette[int(observed)])
        print(f'  {expected}->{observed} mapa {expected_rgb} -> OBS {observed_rgb}: {count}')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
