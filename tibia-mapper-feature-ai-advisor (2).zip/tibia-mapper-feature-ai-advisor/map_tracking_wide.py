"""Live tracker using the proven 27x27 Targuna absolute locator.

Inside Targuna floor 07, the first frame calibrates the 27x27 view against the
manual initial position and every following frame is localized absolutely
against the whole zone map. Guidance advances checkpoint-by-checkpoint: the
tracker never targets a later saved route point until the current point has
actually been detected. Optionally, a completed routine can loop back to its
first saved point and continue recursively.
"""
from __future__ import annotations

from app_paths import RUNTIME_ROOT
from map_tracking import Tracker as LegacyTracker, shortest_path
from zone_signature_index import ZoneIndex, build_zone_index, targuna_floor_07
from zone_wide_locator import (
    WideCalibration,
    WideKnownPositionOptimizer,
    WideZoneLocator,
    sample_wide_histograms,
)

WIDE_MIN_SCORE = .80
WIDE_MIN_GAP = .10

_REFERENCE_WIDTH = 1008.0
_REFERENCE_HEIGHT = 1036.0
_REFERENCE_CENTER_X = 510.0
_REFERENCE_CENTER_Y = 518.0
_REFERENCE_PITCH_X = 37.833
_REFERENCE_PITCH_Y = 38.370
_REFERENCE_PATCH = .18


def wide_match_is_confident(score: float, gap: float) -> bool:
    return float(score) >= WIDE_MIN_SCORE and float(gap) >= WIDE_MIN_GAP


def _default_calibration(width: int, height: int) -> WideCalibration:
    return WideCalibration(
        center_x=float(width) * (_REFERENCE_CENTER_X / _REFERENCE_WIDTH),
        center_y=float(height) * (_REFERENCE_CENTER_Y / _REFERENCE_HEIGHT),
        tile_width=float(width) * (_REFERENCE_PITCH_X / _REFERENCE_WIDTH),
        tile_height=float(height) * (_REFERENCE_PITCH_Y / _REFERENCE_HEIGHT),
        patch_fraction=_REFERENCE_PATCH,
    )


def direction_between(start, end) -> str | None:
    dx = int(end[0]) - int(start[0])
    dy = int(end[1]) - int(start[1])
    if dx > 0 and dy == 0:
        return 'Este'
    if dx < 0 and dy == 0:
        return 'Oeste'
    if dy > 0 and dx == 0:
        return 'Sur'
    if dy < 0 and dx == 0:
        return 'Norte'
    return None


def first_path_direction(path) -> str | None:
    if len(path) < 2:
        return None
    return direction_between(path[0], path[1])


def _find_ordered_plan_indices(plan, targets):
    """Map every saved route point to its corresponding tile index in the expanded plan."""
    result = []
    cursor = 0
    for target in targets:
        found = None
        for index in range(cursor, len(plan)):
            if tuple(plan[index]) == tuple(target):
                found = index
                break
        if found is None:
            raise ValueError(f'El punto de ruta {target} no existe en el camino expandido.')
        result.append(found)
        cursor = found
    return result


def next_target_after_reach(reached_index: int, target_count: int, repeat_routine: bool):
    """Pure checkpoint transition helper used by the tracker and unit tests."""
    next_index = int(reached_index) + 1
    if next_index < int(target_count):
        return next_index, False
    if repeat_routine and target_count:
        return 0, True
    return target_count, False


class Tracker(LegacyTracker):
    """Route tracker with strict saved-point progression and 27x27 localization."""

    def __init__(self, routine, config):
        super().__init__(routine, config)
        self.wide_mode = False
        self.wide_calibration = None
        self.wide_calibrated = False
        self.wide_floor_dir = None
        self.wide_index = None
        self.wide_locator = None
        self.last_guidance_key = None
        self.repeat_routine = bool(config.get('repeat_routine', False))
        self.cycle_count = 0

        self.route_targets = [
            (int(point['x']) - self.origin[0], int(point['y']) - self.origin[1])
            for point in routine['points']
        ]
        self.route_target_plan_indices = _find_ordered_plan_indices(self.plan, self.route_targets)
        self.loop_plan = (
            shortest_path(self.walkable, self.route_targets[-1], [self.route_targets[0]])
            if self.repeat_routine and len(self.route_targets) >= 2
            else []
        )

        initial_world = (int(config['initial_x']), int(config['initial_y']))
        initial_local = (initial_world[0] - self.origin[0], initial_world[1] - self.origin[1])

        self.target_index = 0
        while self.target_index < len(self.route_targets) and initial_local == self.route_targets[self.target_index]:
            self.target_index += 1
        self.progress = 0 if self.target_index == 0 else self.route_target_plan_indices[self.target_index - 1]

        if self.z != 7:
            return

        floor_dir = targuna_floor_07(RUNTIME_ROOT)
        try:
            build_zone_index(floor_dir)
            index = ZoneIndex.load(floor_dir, build_if_missing=False)
            locator = WideZoneLocator(index, floor_dir)
            locator.expected_signature(initial_world)
        except (OSError, ValueError):
            return

        self.wide_mode = True
        self.wide_floor_dir = floor_dir
        self.wide_index = index
        self.wide_locator = locator
        base = _default_calibration(self.region['width'], self.region['height'])
        self.wide_calibration = WideCalibration(
            center_x=float(config.get('wide_center_x', base.center_x)),
            center_y=float(config.get('wide_center_y', base.center_y)),
            tile_width=float(config.get('wide_tile_width', base.tile_width)),
            tile_height=float(config.get('wide_tile_height', base.tile_height)),
            patch_fraction=float(config.get('wide_patch_fraction', _REFERENCE_PATCH)),
        )
        self.event(
            'MODO_27X27',
            'Targuna piso 07 usará localización absoluta 27x27 y avance estricto por puntos de ruta.',
            initial_position=list(initial_world),
            minimum_score=WIDE_MIN_SCORE,
            minimum_gap=WIDE_MIN_GAP,
            route_points=len(self.route_targets),
            repeat_routine=self.repeat_routine,
            current_target=self._target_world(),
            compared_tiles=locator.compared_tiles,
            candidate_positions=len(locator.positions),
        )

    def _target_world(self):
        if self.target_index >= len(self.route_targets):
            return None
        return self.world_points([self.route_targets[self.target_index]])[0]

    def _current_segment(self):
        """Return only the route segment that leads to the current pending checkpoint."""
        if self.target_index >= len(self.route_targets):
            return []
        if self.repeat_routine and self.cycle_count > 0 and self.target_index == 0:
            return self.loop_plan
        end = self.route_target_plan_indices[self.target_index]
        start = 0 if self.target_index == 0 else self.route_target_plan_indices[self.target_index - 1]
        return self.plan[start:end + 1]

    def _emit_guidance(self, kind: str, position, message: str, **extra):
        key = (kind, int(position[0]), int(position[1]), message)
        if key != self.last_guidance_key:
            self.event(kind, message, position=self.world_points([position])[0], **extra)
            self.last_guidance_key = key

    def _advance_only_if_target_reached(self, position) -> bool:
        """Advance exactly one saved checkpoint only after detecting that exact coordinate."""
        if self.target_index >= len(self.route_targets):
            return False
        target = self.route_targets[self.target_index]
        if tuple(position) != tuple(target):
            return False

        reached_index = self.target_index
        reached_world = self.world_points([target])[0]
        self.progress = self.route_target_plan_indices[reached_index]
        next_index, wrapped = next_target_after_reach(
            reached_index, len(self.route_targets), self.repeat_routine
        )
        self.target_index = next_index

        if wrapped:
            self.cycle_count += 1
            self.progress = 0

        next_target = self._target_world()
        self.event(
            'PUNTO_RUTA_ALCANZADO',
            f'Punto de ruta {reached_index + 1}/{len(self.route_targets)} alcanzado en {reached_world}.',
            position=reached_world,
            reached_index=reached_index,
            next_target=next_target,
            cycle=self.cycle_count,
        )
        if wrapped:
            self.event(
                'RUTINA_REPETIDA',
                f'Rutina completada. Iniciando ciclo {self.cycle_count + 1}; el siguiente objetivo vuelve a ser el punto 1/{len(self.route_targets)}: {next_target}.',
                position=reached_world,
                cycle_completed=self.cycle_count,
                next_target=next_target,
            )
        self.last_guidance_key = None
        return True

    def _path_to_pending_target(self, position):
        if self.target_index >= len(self.route_targets):
            return []
        segment = self._current_segment()
        matches = [i for i, point in enumerate(segment) if tuple(point) == tuple(position)]
        if not matches:
            return []
        return segment[matches[-1]:]

    def log_follow_route_direction(self, position) -> dict:
        if self.target_index >= len(self.route_targets):
            self._emit_guidance('RUTA_COMPLETA', position, 'Llegaste al final de la ruta.')
            return {'mode': 'route', 'direction': None, 'message': 'Ruta completada.', 'target': None}

        target_world = self._target_world()
        path = self._path_to_pending_target(position)
        direction = first_path_direction(path)
        message = (
            f'Seguir ruta hacia punto {self.target_index + 1}/{len(self.route_targets)}: '
            f'{direction} hasta {target_world}.'
            if direction else
            f'Seguir ruta hacia punto {self.target_index + 1}/{len(self.route_targets)}: {target_world}.'
        )
        self._emit_guidance(
            'SEGUIR_RUTA', position, message,
            direction=direction,
            target=target_world,
            target_index=self.target_index,
            cycle=self.cycle_count + 1,
        )
        return {
            'mode': 'route', 'direction': direction, 'message': message,
            'target': target_world, 'target_index': self.target_index,
            'cycle': self.cycle_count + 1,
        }

    def log_return_direction(self, position) -> tuple[dict, list]:
        """Return only to the current checkpoint segment; future checkpoints are not valid reentry goals."""
        segment = self._current_segment()
        if not segment:
            raise ValueError('No hay un segmento pendiente al que regresar.')
        path = shortest_path(self.walkable, position, segment)
        direction = first_path_direction(path)
        reentry_world = self.world_points([path[-1]])[0]
        pending_world = self._target_world()
        steps = max(0, len(path) - 1)
        message = (
            f'Volver a ruta: {direction}. Faltan {steps} cuadro(s) para reingresar en {reentry_world}; '
            f'el objetivo pendiente sigue siendo {pending_world}.'
            if direction else
            f'Reingreso en {reentry_world}; el objetivo pendiente sigue siendo {pending_world}.'
        )
        self._emit_guidance(
            'VOLVER_RUTA', position, message,
            direction=direction,
            target=reentry_world,
            pending_target=pending_world,
            target_index=self.target_index,
            cycle=self.cycle_count + 1,
            steps=steps,
        )
        return {
            'mode': 'return', 'direction': direction, 'message': message,
            'target': reentry_world, 'pending_target': pending_world,
            'target_index': self.target_index, 'cycle': self.cycle_count + 1,
            'steps': steps,
        }, path

    def _route_result(self, position, map_score, gap, candidates):
        previous = self.last
        dx, dy = position[0] - previous[0], position[1] - previous[1]

        self._advance_only_if_target_reached(position)

        if self.target_index >= len(self.route_targets):
            route_candidate = 'on_route'
        else:
            route_candidate = 'on_route' if tuple(position) in {tuple(p) for p in self._current_segment()} else 'deviated'

        if route_candidate == self.pending:
            self.count += 1
        else:
            self.pending = route_candidate
            self.count = 1

        world_position = self.world_points([position])[0]
        if self.count >= 2 and route_candidate != self.state:
            kind = ('REGRESO' if self.was_deviated else 'LOCALIZADO') if route_candidate == 'on_route' else 'DESVIO'
            self.event(
                kind,
                ('Regreso confirmado al segmento del objetivo pendiente.' if self.was_deviated else 'Posición confirmada sobre el segmento actual.')
                if route_candidate == 'on_route'
                else 'Desvío confirmado; se mantienen el mismo punto objetivo y las instrucciones de regreso.',
                position=world_position,
                map_score=map_score,
                local_gap=gap,
                current_target=self._target_world(),
                target_index=self.target_index,
                cycle=self.cycle_count + 1,
                locator='27x27-global',
            )
            self.was_deviated = route_candidate == 'deviated'
            self.state = route_candidate

        path = []
        guidance = None
        message = f'Localización absoluta 27x27 confirmada ({map_score:.1%}, separación {gap:.3f}).'
        if route_candidate == 'on_route':
            guidance = self.log_follow_route_direction(position)
            message += f" {guidance['message']}"
        else:
            try:
                guidance, path = self.log_return_direction(position)
                message += f" {guidance['message']}"
            except ValueError as exc:
                message += ' ' + str(exc)
                self._emit_guidance('SIN_CAMINO', position, str(exc))

        self.last = position
        return {
            'state': self.state,
            'route_candidate': route_candidate,
            'message': message,
            'position': world_position,
            'position_stale': False,
            'confidence': map_score,
            'gap': gap,
            'world_confidence': map_score,
            'delta': [dx, dy],
            'relative_delta': None,
            'relative_confidence': None,
            'relative_gap': None,
            'return_path': self.world_points(path),
            'trail': [],
            'guidance': guidance,
            'events': self.events,
            'progress': self.progress,
            'target_index': self.target_index,
            'target_count': len(self.route_targets),
            'current_target': self._target_world(),
            'repeat_routine': self.repeat_routine,
            'cycle': self.cycle_count + 1,
            'locator_mode': '27x27-global',
            'candidates': candidates,
        }

    def _sample_wide(self, frame):
        r = self.region
        if r['x'] + r['width'] > frame.width or r['y'] + r['height'] > frame.height:
            raise ValueError('El recorte queda fuera de la captura actual.')
        crop = frame.crop((r['x'], r['y'], r['x'] + r['width'], r['y'] + r['height']))

        if not self.wide_calibrated:
            initial_world = tuple(self.world_points([self.last])[0])
            optimizer = WideKnownPositionOptimizer(crop, self.wide_locator, initial_world)
            before = optimizer.score(self.wide_calibration)
            optimization = optimizer.optimize(self.wide_calibration)
            self.wide_calibration = optimization['best']
            self.wide_calibrated = True
            self.event(
                'CALIBRACION_27X27',
                f'Calibración automática 27x27 optimizada de {before:.1%} a {optimization["best_score"]:.1%}.',
                position=list(initial_world), before=round(before, 4), after=optimization['best_score'],
            )

        hist = sample_wide_histograms(crop, self.wide_calibration, self.wide_index.palette)
        world_position, score, gap, top = self.wide_locator.locate(hist, top_k=10)
        candidates = [
            {'position': c['position'], 'score': c['score'], 'map_score': c['score'], 'combined': c['score']}
            for c in top
        ]
        if not wide_match_is_confident(score, gap):
            return self._unknown(
                f'Localización 27x27 no confiable: coincidencia {score:.1%}, separación {gap:.3f}; '
                f'se requiere {WIDE_MIN_SCORE:.0%} y {WIDE_MIN_GAP:.2f}.', candidates=candidates,
            )

        local_position = (world_position[0] - self.origin[0], world_position[1] - self.origin[1])
        h, w = self.walkable.shape
        if not (0 <= local_position[0] < w and 0 <= local_position[1] < h):
            return self._unknown('La posición 27x27 detectada queda fuera del mapa global.', candidates=candidates)
        if not self.walkable[local_position[1], local_position[0]]:
            return self._unknown('La posición 27x27 detectada no es transitable.', candidates=candidates)
        return self._route_result(local_position, score, gap, candidates)

    def sample(self, frame):
        if self.wide_mode:
            return self._sample_wide(frame)
        return super().sample(frame)
