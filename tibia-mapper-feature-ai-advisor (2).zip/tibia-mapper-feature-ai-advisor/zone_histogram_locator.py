"""Histogram-based absolute locator for a cropped tibia-map-data zone.

Each OBS minimap tile is represented by a distribution over the zone map's own
palette instead of a single median RGB value. The precomputed 13x13 signatures
from zone_signature_index remain the map-side reference.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from PIL import Image, ImageDraw

from zone_signature_index import CENTER_MASK_RADIUS, WINDOW, ZoneIndex, quantize_to_palette

HALF = WINDOW // 2


def center_mask() -> np.ndarray:
    mask = np.ones((WINDOW, WINDOW), dtype=bool)
    c = WINDOW // 2
    r = CENTER_MASK_RADIUS
    mask[c-r:c+r+1, c-r:c+r+1] = False
    return mask


@dataclass(frozen=True)
class HistogramCalibration:
    center_x: float
    center_y: float
    tile_width: float
    tile_height: float


def _tile_patch(rgb: np.ndarray, cx: float, cy: float, tile_w: float, tile_h: float, fraction: float = .55) -> np.ndarray:
    """Take a generous central patch from one rendered minimap tile."""
    patch_w = max(6, int(round(tile_w * fraction)))
    patch_h = max(6, int(round(tile_h * fraction)))
    x0 = max(0, int(round(cx - patch_w / 2.0)))
    y0 = max(0, int(round(cy - patch_h / 2.0)))
    x1 = min(rgb.shape[1], int(round(cx + patch_w / 2.0)) + 1)
    y1 = min(rgb.shape[0], int(round(cy + patch_h / 2.0)) + 1)
    if x1 <= x0 or y1 <= y0:
        raise ValueError('Un tile calibrado queda fuera del recorte OBS.')
    return rgb[y0:y1, x0:x1]


def sample_histogram_grid(image: Image.Image, calibration: HistogramCalibration, palette: np.ndarray) -> np.ndarray:
    """Return 13x13xP palette histograms from the rendered OBS minimap."""
    rgb = np.asarray(image.convert('RGB'), dtype=np.uint8)
    palette = np.asarray(palette, dtype=np.uint8)
    if palette.ndim != 2 or palette.shape[1] != 3 or len(palette) == 0:
        raise ValueError('La paleta del índice de zona es inválida.')

    result = np.zeros((WINDOW, WINDOW, len(palette)), dtype=np.float32)
    for gy in range(-HALF, HALF + 1):
        for gx in range(-HALF, HALF + 1):
            cx = calibration.center_x + gx * calibration.tile_width
            cy = calibration.center_y + gy * calibration.tile_height
            patch = _tile_patch(rgb, cx, cy, calibration.tile_width, calibration.tile_height)
            classes = quantize_to_palette(patch, palette)
            hist = np.bincount(classes.reshape(-1), minlength=len(palette)).astype(np.float32)
            total = float(hist.sum())
            if total:
                hist /= total
            result[gy + HALF, gx + HALF] = hist
    return result


class HistogramZoneLocator:
    def __init__(self, index: ZoneIndex):
        self.index = index
        self.mask = center_mask()
        self.tile_count = int(self.mask.sum())

    def _candidate_arrays(self, near=None, max_distance: int | None = None):
        positions = self.index.positions
        signatures = self.index.signatures
        if near is not None and max_distance is not None:
            near_array = np.asarray(near, dtype=np.int32)
            distance = np.max(np.abs(positions - near_array[None, :]), axis=1)
            keep = distance <= int(max_distance)
            if np.any(keep):
                positions = positions[keep]
                signatures = signatures[keep]
        return positions, signatures

    def _scores(self, hist_grid: np.ndarray, signatures: np.ndarray) -> np.ndarray:
        hist = np.asarray(hist_grid, dtype=np.float32)
        if hist.shape[:2] != (WINDOW, WINDOW) or hist.shape[2] != len(self.index.palette):
            raise ValueError('La grilla de histogramas debe medir 13x13xP para la paleta del índice.')
        observed = hist[self.mask]
        if signatures.shape[1] != observed.shape[0]:
            raise ValueError('La firma del índice no coincide con la máscara 5x5 actual.')

        tile_ids = np.arange(observed.shape[0], dtype=np.int32)[None, :]
        per_tile = observed[tile_ids, signatures]
        weights = self.index.rarity[signatures]
        numerator = (per_tile * weights).sum(axis=1)
        denominator = np.maximum(weights.sum(axis=1), 1e-9)
        return numerator / denominator

    def score_position(self, hist_grid: np.ndarray, position) -> float:
        target = np.asarray(position, dtype=np.int32)
        matches = np.all(self.index.positions == target[None, :], axis=1)
        if not np.any(matches):
            return 0.0
        idx = int(np.flatnonzero(matches)[0])
        return round(float(self._scores(hist_grid, self.index.signatures[idx:idx+1])[0]), 4)

    def expected_signature(self, position) -> np.ndarray:
        target = np.asarray(position, dtype=np.int32)
        matches = np.all(self.index.positions == target[None, :], axis=1)
        if not np.any(matches):
            raise ValueError(f'La posición conocida {tuple(position)} no está indexada en esta zona.')
        return self.index.signatures[int(np.flatnonzero(matches)[0])].copy()

    def locate(self, hist_grid: np.ndarray, *, near=None, max_distance: int | None = None, top_k: int = 10):
        positions, signatures = self._candidate_arrays(near, max_distance)
        if len(positions) == 0:
            raise ValueError('No hay posiciones candidatas en la zona.')
        scores = self._scores(hist_grid, signatures)
        if near is not None:
            distance = np.max(np.abs(positions - np.asarray(near, dtype=np.int32)[None, :]), axis=1)
            combined = scores - np.minimum(distance, 20) * .002
        else:
            combined = scores

        order = np.argsort(combined)[::-1]
        best = int(order[0])
        second = int(order[1]) if len(order) > 1 else best
        gap = float(combined[best] - combined[second]) if len(order) > 1 else 1.0
        top = []
        for idx in order[:max(1, int(top_k))]:
            top.append({
                'position': [int(positions[idx, 0]), int(positions[idx, 1])],
                'score': round(float(scores[idx]), 4),
                'combined': round(float(combined[idx]), 4),
            })
        return (
            (int(positions[best, 0]), int(positions[best, 1])),
            round(float(scores[best]), 4),
            round(gap, 4),
            top,
        )

    def debug_known(self, hist_grid: np.ndarray, position) -> dict:
        expected = self.expected_signature(position)
        observed = np.asarray(hist_grid, dtype=np.float32)[self.mask]
        probability = observed[np.arange(len(expected)), expected]
        dominant = observed.argmax(axis=1)
        weight = self.index.rarity[expected]

        labels = []
        cursor = 0
        for gy in range(WINDOW):
            row = []
            for gx in range(WINDOW):
                if not self.mask[gy, gx]:
                    row.append('X')
                    continue
                p = float(probability[cursor])
                row.append('G' if p >= .70 else 'Y' if p >= .40 else 'R')
                cursor += 1
            labels.append(row)

        confusion = {}
        for exp, dom in zip(expected.tolist(), dominant.tolist()):
            if exp == dom:
                continue
            key = f'{exp}->{dom}'
            confusion[key] = confusion.get(key, 0) + 1

        score = float((probability * weight).sum() / max(float(weight.sum()), 1e-9))
        return {
            'score': round(score, 4),
            'labels': labels,
            'good': int(np.sum(probability >= .70)),
            'medium': int(np.sum((probability >= .40) & (probability < .70))),
            'bad': int(np.sum(probability < .40)),
            'confusion': sorted(confusion.items(), key=lambda item: item[1], reverse=True),
            'probability': probability,
        }


class KnownPositionCalibrationOptimizer:
    """Tune minimap geometry against one trusted world coordinate.

    The crop is quantized once. Candidate calibrations are then scored with
    class-specific integral images, so hundreds of geometry trials are cheap.
    """

    def __init__(self, crop: Image.Image, locator: HistogramZoneLocator, known_position, patch_fraction: float = .55):
        self.crop = crop.convert('RGB')
        self.locator = locator
        self.known_position = tuple(map(int, known_position))
        self.patch_fraction = float(patch_fraction)
        self.expected = locator.expected_signature(self.known_position)
        self.weights = locator.index.rarity[self.expected].astype(np.float64)

        rgb = np.asarray(self.crop, dtype=np.uint8)
        self.class_map = quantize_to_palette(rgb, locator.index.palette)
        self.height, self.width = self.class_map.shape
        self.integrals = {}
        for class_id in np.unique(self.expected):
            binary = (self.class_map == int(class_id)).astype(np.int32)
            integral = np.zeros((self.height + 1, self.width + 1), dtype=np.int32)
            integral[1:, 1:] = binary.cumsum(axis=0).cumsum(axis=1)
            self.integrals[int(class_id)] = integral

        self.active_tiles = []
        cursor = 0
        mask = locator.mask
        for gy in range(WINDOW):
            for gx in range(WINDOW):
                if not mask[gy, gx]:
                    continue
                self.active_tiles.append((gx - HALF, gy - HALF, int(self.expected[cursor]), float(self.weights[cursor])))
                cursor += 1

    @staticmethod
    def _rect_sum(integral, x0, y0, x1, y1):
        return int(integral[y1, x1] - integral[y0, x1] - integral[y1, x0] + integral[y0, x0])

    def score(self, calibration: HistogramCalibration) -> float:
        if calibration.tile_width <= 2 or calibration.tile_height <= 2:
            return 0.0
        patch_w = max(6, int(round(calibration.tile_width * self.patch_fraction)))
        patch_h = max(6, int(round(calibration.tile_height * self.patch_fraction)))
        weighted = 0.0
        total_weight = 0.0

        for gx, gy, class_id, weight in self.active_tiles:
            cx = calibration.center_x + gx * calibration.tile_width
            cy = calibration.center_y + gy * calibration.tile_height
            x0 = int(round(cx - patch_w / 2.0))
            y0 = int(round(cy - patch_h / 2.0))
            x1 = x0 + patch_w
            y1 = y0 + patch_h
            if x0 < 0 or y0 < 0 or x1 > self.width or y1 > self.height:
                return 0.0
            area = max((x1 - x0) * (y1 - y0), 1)
            count = self._rect_sum(self.integrals[class_id], x0, y0, x1, y1)
            weighted += (count / area) * weight
            total_weight += weight

        return float(weighted / max(total_weight, 1e-9))

    @staticmethod
    def _values(center: float, radius: float, step: float):
        count = int(round((radius * 2) / step))
        return [center - radius + i * step for i in range(count + 1)]

    def _search_pair(self, base: HistogramCalibration, fields, radius_a, step_a, radius_b, step_b):
        best = base
        best_score = self.score(base)
        values_a = self._values(getattr(base, fields[0]), radius_a, step_a)
        values_b = self._values(getattr(base, fields[1]), radius_b, step_b)
        for a in values_a:
            for b in values_b:
                values = {
                    'center_x': base.center_x,
                    'center_y': base.center_y,
                    'tile_width': base.tile_width,
                    'tile_height': base.tile_height,
                }
                values[fields[0]] = float(a)
                values[fields[1]] = float(b)
                candidate = HistogramCalibration(**values)
                score = self.score(candidate)
                if score > best_score:
                    best, best_score = candidate, score
        return best, best_score

    def optimize(self, initial: HistogramCalibration) -> dict:
        original_score = self.score(initial)
        best = initial
        history = [('inicial', best, original_score)]

        # Coarse center, coarse pitch, then two refinement passes.
        best, score = self._search_pair(best, ('center_x', 'center_y'), 24.0, 6.0, 24.0, 6.0)
        history.append(('centro-grueso', best, score))
        best, score = self._search_pair(best, ('tile_width', 'tile_height'), 4.0, 1.0, 4.0, 1.0)
        history.append(('tile-grueso', best, score))
        best, score = self._search_pair(best, ('center_x', 'center_y'), 5.0, 1.0, 5.0, 1.0)
        history.append(('centro-fino', best, score))
        best, score = self._search_pair(best, ('tile_width', 'tile_height'), 1.5, .5, 1.5, .5)
        history.append(('tile-fino', best, score))
        best, score = self._search_pair(best, ('center_x', 'center_y'), 1.0, .25, 1.0, .25)
        history.append(('centro-extra', best, score))

        return {
            'initial': initial,
            'initial_score': round(original_score, 4),
            'best': best,
            'best_score': round(score, 4),
            'history': [
                {
                    'stage': stage,
                    'calibration': calibration,
                    'score': round(stage_score, 4),
                }
                for stage, calibration, stage_score in history
            ],
        }


def draw_histogram_debug(crop: Image.Image, calibration: HistogramCalibration, debug: dict, output) -> None:
    """Overlay known-position match quality: green/yellow/red, center X ignored."""
    image = crop.convert('RGB').copy()
    draw = ImageDraw.Draw(image)
    labels = debug['labels']
    for gy in range(-HALF, HALF + 1):
        for gx in range(-HALF, HALF + 1):
            cx = calibration.center_x + gx * calibration.tile_width
            cy = calibration.center_y + gy * calibration.tile_height
            label = labels[gy + HALF][gx + HALF]
            if label == 'X':
                color = (255, 255, 255)
            elif label == 'G':
                color = (0, 255, 0)
            elif label == 'Y':
                color = (255, 230, 0)
            else:
                color = (255, 40, 40)
            r = 6
            draw.ellipse((cx-r, cy-r, cx+r, cy+r), outline=color, width=3)
    output.parent.mkdir(parents=True, exist_ok=True)
    image.save(output)
