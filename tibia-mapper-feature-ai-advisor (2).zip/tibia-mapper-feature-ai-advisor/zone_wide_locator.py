"""Wide absolute minimap localization for one cropped tibia-map-data zone.

The rendered Tibia minimap exposes roughly 27 logical positions across the crop.
This module samples every logical position instead of the older 13x13/every-other-
tile approximation, then compares the resulting 27x27 visual signature against
all centers in the selected zone map.
"""
from __future__ import annotations

from dataclasses import dataclass, replace
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw

from zone_signature_index import ZoneIndex, quantize_to_palette

GRID_SIZE = 27
HALF = GRID_SIZE // 2
CENTER_MASK_RADIUS = 2  # keep the same 5x5 player-marker exclusion
DEFAULT_PATCH_FRACTION = .38


def wide_mask() -> np.ndarray:
    mask = np.ones((GRID_SIZE, GRID_SIZE), dtype=bool)
    c = HALF
    r = CENTER_MASK_RADIUS
    mask[c-r:c+r+1, c-r:c+r+1] = False
    return mask


@dataclass(frozen=True)
class WideCalibration:
    center_x: float
    center_y: float
    tile_width: float
    tile_height: float
    patch_fraction: float = DEFAULT_PATCH_FRACTION


def default_wide_calibration(crop: Image.Image, center_x: float | None = None, center_y: float | None = None) -> WideCalibration:
    """Initial geometry for a 27x27 view.

    The full crop contains margins, so width/27 and height/27 are only an initial
    pitch estimate. The known-position optimizer refines them before localization.
    """
    return WideCalibration(
        center_x=float((crop.width - 1) / 2 if center_x is None else center_x),
        center_y=float((crop.height - 1) / 2 if center_y is None else center_y),
        tile_width=float(crop.width / GRID_SIZE),
        tile_height=float(crop.height / GRID_SIZE),
        patch_fraction=DEFAULT_PATCH_FRACTION,
    )


def _tile_patch(rgb: np.ndarray, cx: float, cy: float, tile_w: float, tile_h: float, fraction: float) -> np.ndarray:
    patch_w = max(4, int(round(tile_w * fraction)))
    patch_h = max(4, int(round(tile_h * fraction)))
    x0 = int(round(cx - patch_w / 2.0))
    y0 = int(round(cy - patch_h / 2.0))
    x1 = x0 + patch_w
    y1 = y0 + patch_h
    if x0 < 0 or y0 < 0 or x1 > rgb.shape[1] or y1 > rgb.shape[0]:
        raise ValueError('La grilla 27x27 sale del recorte OBS; ajusta centro o pitch.')
    return rgb[y0:y1, x0:x1]


def sample_wide_histograms(image: Image.Image, calibration: WideCalibration, palette: np.ndarray) -> np.ndarray:
    """Return 27x27xP histograms, one color distribution per logical map position."""
    rgb = np.asarray(image.convert('RGB'), dtype=np.uint8)
    palette = np.asarray(palette, dtype=np.uint8)
    result = np.zeros((GRID_SIZE, GRID_SIZE, len(palette)), dtype=np.float32)
    for gy in range(-HALF, HALF + 1):
        for gx in range(-HALF, HALF + 1):
            cx = calibration.center_x + gx * calibration.tile_width
            cy = calibration.center_y + gy * calibration.tile_height
            patch = _tile_patch(
                rgb, cx, cy, calibration.tile_width, calibration.tile_height, calibration.patch_fraction
            )
            classes = quantize_to_palette(patch, palette)
            hist = np.bincount(classes.reshape(-1), minlength=len(palette)).astype(np.float32)
            total = float(hist.sum())
            if total:
                hist /= total
            result[gy + HALF, gx + HALF] = hist
    return result


class WideZoneLocator:
    def __init__(self, index: ZoneIndex, floor_dir: Path):
        self.index = index
        self.floor_dir = Path(floor_dir)
        self.mask = wide_mask()
        with Image.open(self.floor_dir / 'map.png') as image:
            rgb = np.asarray(image.convert('RGB'), dtype=np.uint8)
        self.classes = quantize_to_palette(rgb, index.palette)
        self.left, self.top, self.right, self.bottom = index.bbox

        positions = []
        signatures = []
        h, w = self.classes.shape
        for y in range(HALF, h - HALF):
            for x in range(HALF, w - HALF):
                patch = self.classes[y-HALF:y+HALF+1, x-HALF:x+HALF+1]
                positions.append((self.left + x, self.top + y))
                signatures.append(patch[self.mask])
        if not positions:
            raise ValueError('La zona es demasiado pequeña para una firma 27x27.')
        self.positions = np.asarray(positions, dtype=np.int32)
        self.signatures = np.asarray(signatures, dtype=np.uint8)

    @property
    def compared_tiles(self) -> int:
        return int(self.mask.sum())

    def expected_signature(self, position) -> np.ndarray:
        target = np.asarray(tuple(map(int, position)), dtype=np.int32)
        matches = np.all(self.positions == target[None, :], axis=1)
        if not np.any(matches):
            raise ValueError(f'La posición {tuple(target.tolist())} no admite ventana 27x27 dentro de Targuna.')
        return self.signatures[int(np.flatnonzero(matches)[0])].copy()

    def _scores(self, hist_grid: np.ndarray, signatures: np.ndarray) -> np.ndarray:
        hist = np.asarray(hist_grid, dtype=np.float32)
        if hist.shape[:2] != (GRID_SIZE, GRID_SIZE) or hist.shape[2] != len(self.index.palette):
            raise ValueError('La grilla visual debe medir 27x27xP.')
        observed = hist[self.mask]
        tile_ids = np.arange(observed.shape[0], dtype=np.int32)[None, :]
        per_tile = observed[tile_ids, signatures]
        weights = self.index.rarity[signatures]
        return (per_tile * weights).sum(axis=1) / np.maximum(weights.sum(axis=1), 1e-9)

    def score_position(self, hist_grid: np.ndarray, position) -> float:
        expected = self.expected_signature(position)[None, :]
        return round(float(self._scores(hist_grid, expected)[0]), 4)

    def locate(self, hist_grid: np.ndarray, *, top_k: int = 10):
        scores = self._scores(hist_grid, self.signatures)
        order = np.argsort(scores)[::-1]
        best = int(order[0])
        second = int(order[1]) if len(order) > 1 else best
        gap = float(scores[best] - scores[second]) if len(order) > 1 else 1.0
        top = []
        for idx in order[:max(1, int(top_k))]:
            top.append({
                'position': [int(self.positions[idx, 0]), int(self.positions[idx, 1])],
                'score': round(float(scores[idx]), 4),
            })
        return (
            (int(self.positions[best, 0]), int(self.positions[best, 1])),
            round(float(scores[best]), 4),
            round(gap, 4),
            top,
        )

    def debug_known(self, hist_grid: np.ndarray, position) -> dict:
        expected = self.expected_signature(position)
        observed = np.asarray(hist_grid, dtype=np.float32)[self.mask]
        probability = observed[np.arange(len(expected)), expected]
        dominant = observed.argmax(axis=1)
        weights = self.index.rarity[expected]
        score = float((probability * weights).sum() / max(float(weights.sum()), 1e-9))

        labels = []
        cursor = 0
        for gy in range(GRID_SIZE):
            row = []
            for gx in range(GRID_SIZE):
                if not self.mask[gy, gx]:
                    row.append('X')
                    continue
                p = float(probability[cursor])
                row.append('G' if p >= .70 else 'Y' if p >= .40 else 'R')
                cursor += 1
            labels.append(row)

        confusion = {}
        for exp, dom in zip(expected.tolist(), dominant.tolist()):
            if exp != dom:
                key = f'{exp}->{dom}'
                confusion[key] = confusion.get(key, 0) + 1
        return {
            'score': round(score, 4),
            'labels': labels,
            'good': int(np.sum(probability >= .70)),
            'medium': int(np.sum((probability >= .40) & (probability < .70))),
            'bad': int(np.sum(probability < .40)),
            'confusion': sorted(confusion.items(), key=lambda item: item[1], reverse=True),
        }


class WideKnownPositionOptimizer:
    """Tune 27x27 center, pitch and inner patch size against one trusted coordinate."""

    def __init__(self, crop: Image.Image, locator: WideZoneLocator, known_position):
        self.crop = crop.convert('RGB')
        self.locator = locator
        self.known = tuple(map(int, known_position))
        self.expected = locator.expected_signature(self.known)
        self.weights = locator.index.rarity[self.expected].astype(np.float64)
        self.mask = locator.mask

        rgb = np.asarray(self.crop, dtype=np.uint8)
        self.class_map = quantize_to_palette(rgb, locator.index.palette)
        self.height, self.width = self.class_map.shape
        self.integrals = {}
        for class_id in np.unique(self.expected):
            binary = (self.class_map == int(class_id)).astype(np.int32)
            integral = np.zeros((self.height + 1, self.width + 1), dtype=np.int32)
            integral[1:, 1:] = binary.cumsum(axis=0).cumsum(axis=1)
            self.integrals[int(class_id)] = integral

        self.active = []
        cursor = 0
        for gy in range(GRID_SIZE):
            for gx in range(GRID_SIZE):
                if not self.mask[gy, gx]:
                    continue
                self.active.append((gx-HALF, gy-HALF, int(self.expected[cursor]), float(self.weights[cursor])))
                cursor += 1

    @staticmethod
    def _rect_sum(integral, x0, y0, x1, y1):
        return int(integral[y1, x1] - integral[y0, x1] - integral[y1, x0] + integral[y0, x0])

    def score(self, calibration: WideCalibration) -> float:
        if calibration.tile_width <= 3 or calibration.tile_height <= 3:
            return 0.0
        if not .12 <= calibration.patch_fraction <= .75:
            return 0.0
        patch_w = max(4, int(round(calibration.tile_width * calibration.patch_fraction)))
        patch_h = max(4, int(round(calibration.tile_height * calibration.patch_fraction)))
        weighted = 0.0
        total = 0.0
        for gx, gy, class_id, weight in self.active:
            cx = calibration.center_x + gx * calibration.tile_width
            cy = calibration.center_y + gy * calibration.tile_height
            x0 = int(round(cx - patch_w / 2.0))
            y0 = int(round(cy - patch_h / 2.0))
            x1 = x0 + patch_w
            y1 = y0 + patch_h
            if x0 < 0 or y0 < 0 or x1 > self.width or y1 > self.height:
                return 0.0
            area = max((x1-x0)*(y1-y0), 1)
            count = self._rect_sum(self.integrals[class_id], x0, y0, x1, y1)
            weighted += (count / area) * weight
            total += weight
        return float(weighted / max(total, 1e-9))

    @staticmethod
    def _values(center: float, radius: float, step: float):
        count = int(round((2 * radius) / step))
        return [center - radius + i * step for i in range(count + 1)]

    def _search_pair(self, base: WideCalibration, fields, radius_a, step_a, radius_b, step_b):
        best, best_score = base, self.score(base)
        for a in self._values(getattr(base, fields[0]), radius_a, step_a):
            for b in self._values(getattr(base, fields[1]), radius_b, step_b):
                candidate = replace(base, **{fields[0]: float(a), fields[1]: float(b)})
                score = self.score(candidate)
                if score > best_score:
                    best, best_score = candidate, score
        return best, best_score

    def _search_fraction(self, base: WideCalibration, values):
        best, best_score = base, self.score(base)
        for value in values:
            candidate = replace(base, patch_fraction=float(value))
            score = self.score(candidate)
            if score > best_score:
                best, best_score = candidate, score
        return best, best_score

    def optimize(self, initial: WideCalibration) -> dict:
        best = initial
        history = [('inicial', best, self.score(best))]
        best, score = self._search_pair(best, ('center_x', 'center_y'), 18, 6, 18, 6)
        history.append(('centro-grueso', best, score))
        best, score = self._search_pair(best, ('tile_width', 'tile_height'), 5, 1, 5, 1)
        history.append(('pitch-grueso', best, score))
        best, score = self._search_fraction(best, [.22, .30, .38, .46, .54, .62])
        history.append(('parche-grueso', best, score))
        best, score = self._search_pair(best, ('center_x', 'center_y'), 4, 1, 4, 1)
        history.append(('centro-fino', best, score))
        best, score = self._search_pair(best, ('tile_width', 'tile_height'), 1.5, .5, 1.5, .5)
        history.append(('pitch-fino', best, score))
        fractions = self._values(best.patch_fraction, .06, .02)
        best, score = self._search_fraction(best, fractions)
        history.append(('parche-fino', best, score))
        return {
            'best': best,
            'best_score': round(score, 4),
            'history': [
                {'stage': stage, 'calibration': calibration, 'score': round(stage_score, 4)}
                for stage, calibration, stage_score in history
            ],
        }


def draw_wide_debug(crop: Image.Image, calibration: WideCalibration, debug: dict, output: Path) -> None:
    image = crop.convert('RGB').copy()
    draw = ImageDraw.Draw(image)
    labels = debug['labels']
    for gy in range(-HALF, HALF + 1):
        for gx in range(-HALF, HALF + 1):
            cx = calibration.center_x + gx * calibration.tile_width
            cy = calibration.center_y + gy * calibration.tile_height
            label = labels[gy+HALF][gx+HALF]
            color = (255,255,255) if label == 'X' else (0,255,0) if label == 'G' else (255,230,0) if label == 'Y' else (255,40,40)
            r = 3
            draw.ellipse((cx-r, cy-r, cx+r, cy+r), outline=color, width=2)
    output.parent.mkdir(parents=True, exist_ok=True)
    image.save(output)
