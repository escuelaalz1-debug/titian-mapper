import io
import os
import threading
from time import perf_counter
from flask import jsonify, render_template, request, send_file
from keyboard_helpers import press_direction
from map_battle_coordinator import MapBattleCoordinator
from map_routine_store import list_map_routines
from map_tracking_targuna import Tracker
import tibia_map_service as maps


def register_tracking_routes(app):
    state = {'tracker': None, 'last_sample_started': None}
    default_obs_password = os.getenv('OBS_WEBSOCKET_PASSWORD', '')
    obs = {'scene': 'PanelDatos', 'source': 'Mapa', 'port': 4455, 'password': default_obs_password}
    lock = threading.Lock()
    battle = MapBattleCoordinator()

    def frame():
        from obs_scene_capture import capture_scene, capture_source
        common = {'port': obs['port'], 'password': obs['password']}
        if obs['source']:
            return capture_source(obs['source'], **common)
        return capture_scene(obs['scene'], **common)

    def routine_from_payload(payload):
        routine = next((r for r in list_map_routines() if r['id'] == payload.get('routine_id')), None)
        if not routine:
            raise ValueError('Selecciona una rutina guardada.')
        return routine

    @app.post('/api/map/tracking/obs')
    def tracking_obs():
        with lock:
            if state['tracker'] is not None:
                return jsonify(ok=False, error='Detén el seguimiento antes de cambiar la captura OBS.'), 400
            try:
                data = request.get_json() or {}
                scene = str(data.get('scene', 'PanelDatos')).strip()
                source = str(data.get('source', 'Mapa')).strip()
                port = int(data.get('port', 4455))
                password = data.get('password', default_obs_password)
                if not scene or not 1 <= port <= 65535 or not isinstance(password, str):
                    raise ValueError()
                obs.update(scene=scene, source=source, port=port, password=password)
                return jsonify(ok=True, mode='source' if source else 'scene', target=source or scene)
            except (ValueError, TypeError, AttributeError):
                return jsonify(ok=False, error='Nombre de escena/fuente o puerto inválidos.'), 400

    @app.get('/maps/tracking')
    def tracking_view():
        return render_template('map_tracking.html', obs_password=default_obs_password)

    @app.get('/api/map/tracking/capture')
    def tracking_capture():
        try:
            buffer = io.BytesIO()
            frame().save(buffer, format='PNG')
            buffer.seek(0)
            response = send_file(buffer, mimetype='image/png', max_age=0)
            response.headers['Cache-Control'] = 'no-store'
            response.headers['X-OBS-Capture-Mode'] = 'source' if obs['source'] else 'scene'
            response.headers['X-OBS-Capture-Target'] = obs['source'] or obs['scene']
            return response
        except Exception as exc:
            return jsonify(ok=False, error=str(exc)), 400

    @app.get('/api/map/tracking/floor/<int:z>')
    def tracking_floor(z):
        if not 0 <= z <= 15:
            return jsonify(ok=False, error='Piso inválido'), 400
        return send_file(maps._floor_map_path(z), max_age=0)

    @app.post('/api/map/tracking/prepare')
    def tracking_prepare():
        with lock:
            if state['tracker'] is not None:
                return jsonify(ok=False, error='Detén el seguimiento actual antes de elegir otra posición inicial.'), 400
            try:
                payload = request.get_json() or {}
                routine = routine_from_payload(payload)
                return jsonify(ok=True, **Tracker.prepare(routine))
            except (ValueError, KeyError, TypeError, OSError) as exc:
                return jsonify(ok=False, error=str(exc)), 400

    @app.post('/api/map/tracking/start')
    def tracking_start():
        with lock:
            try:
                payload = request.get_json() or {}
                routine = routine_from_payload(payload)
                tracker = Tracker(routine, payload)
                state['tracker'] = tracker
                state['last_sample_started'] = None
                battle.reset()
                return jsonify(
                    ok=True,
                    z=tracker.z,
                    origin=tracker.origin,
                    plan=tracker.world_points(tracker.plan),
                    position=tracker.world_points([tracker.last])[0],
                    log_file=tracker.log_path.name,
                    locator_mode='27x27-global' if getattr(tracker, 'wide_mode', False) else 'legacy-13x13',
                )
            except (ValueError, KeyError, TypeError, OSError) as exc:
                return jsonify(ok=False, error=str(exc)), 400

    @app.post('/api/map/tracking/sample')
    def tracking_sample():
        with lock:
            tracker = state['tracker']
            if tracker is None:
                return jsonify(ok=False, error='Inicia el seguimiento.'), 400

            started = perf_counter()
            previous_started = state['last_sample_started']
            state['last_sample_started'] = started
            since_previous_ms = None if previous_started is None else (started - previous_started) * 1000.0
            capture_ms = None
            analysis_ms = None
            try:
                battle_result = battle.step(tracker)
                if battle_result is not None:
                    total_ms = (perf_counter() - started) * 1000.0
                    battle_result['timing'] = {
                        'since_previous_ms': round(since_previous_ms, 2) if since_previous_ms is not None else None,
                        'capture_ms': None,
                        'analysis_ms': None,
                        'total_ms': round(total_ms, 2),
                    }
                    tracker.event(
                        'PERF_BATTLE_PAUSA',
                        f"Ruta pausada por Battle · total {total_ms:.2f} ms.",
                        battle_state=battle_result.get('battle_state'),
                    )
                    battle_result['events'] = tracker.events
                    return jsonify(ok=True, **battle_result)

                capture_started = perf_counter()
                image = frame()
                capture_ms = (perf_counter() - capture_started) * 1000.0

                analysis_started = perf_counter()
                result = tracker.sample(image)
                analysis_ms = (perf_counter() - analysis_started) * 1000.0
                total_ms = (perf_counter() - started) * 1000.0

                timing = {
                    'since_previous_ms': round(since_previous_ms, 2) if since_previous_ms is not None else None,
                    'capture_ms': round(capture_ms, 2),
                    'analysis_ms': round(analysis_ms, 2),
                    'total_ms': round(total_ms, 2),
                }
                result['timing'] = timing
                result['battle_paused'] = False
                position = result.get('position')
                delta = result.get('delta')
                confidence = result.get('confidence')
                gap = result.get('gap')
                world_confidence = result.get('world_confidence')
                relative_delta = result.get('relative_delta')
                relative_confidence = result.get('relative_confidence')
                candidates = result.get('candidates') or []
                guidance = result.get('guidance') or {}
                cadence = f" · intervalo {timing['since_previous_ms']:.0f} ms" if timing['since_previous_ms'] is not None else ''
                candidate_text = ' | '.join(
                    f"{c.get('position')}:{c.get('map_score', c.get('score'))}" for c in candidates[:3]
                ) or '-'
                detail = (
                    f" · pos {position} · delta {delta}"
                    f" · mapa {world_confidence if world_confidence is not None else '-'}"
                    f" · gap {gap if gap is not None else '-'}"
                    f" · relativo {relative_delta if relative_delta is not None else '-'}"
                    f"/{relative_confidence if relative_confidence is not None else '-'}"
                    f" · localizador {result.get('locator_mode', 'legacy-13x13')}"
                    f" · instrucción {guidance.get('mode', '-')}/{guidance.get('direction', '-')}"
                    f" · top {candidate_text}"
                )
                tracker.event(
                    'PERF_POSICION',
                    f"Captura {timing['capture_ms']:.2f} ms · análisis {timing['analysis_ms']:.2f} ms · total {timing['total_ms']:.2f} ms{cadence}{detail}.",
                    timing=timing,
                    position=position,
                    state=result.get('state'),
                    route_candidate=result.get('route_candidate'),
                    confidence=confidence,
                    gap=gap,
                    world_confidence=world_confidence,
                    delta=delta,
                    relative_delta=relative_delta,
                    relative_confidence=relative_confidence,
                    candidates=candidates,
                    guidance=guidance or None,
                    locator_mode=result.get('locator_mode'),
                    position_stale=result.get('position_stale', False),
                )
                return jsonify(ok=True, **result)
            except Exception as exc:
                total_ms = (perf_counter() - started) * 1000.0
                timing = {
                    'since_previous_ms': round(since_previous_ms, 2) if since_previous_ms is not None else None,
                    'capture_ms': round(capture_ms, 2) if capture_ms is not None else None,
                    'analysis_ms': round(analysis_ms, 2) if analysis_ms is not None else None,
                    'total_ms': round(total_ms, 2),
                }
                tracker.event(
                    'PERF_ERROR',
                    f"Muestra falló tras {timing['total_ms']:.2f} ms · intervalo {timing['since_previous_ms']} ms · captura {timing['capture_ms']} ms · análisis {timing['analysis_ms']} ms · {exc}",
                    timing=timing,
                    error=str(exc),
                    last_known=tracker.world_points([tracker.last])[0],
                )
                if tracker.state != 'unknown':
                    tracker.event('POSICION_DESCONOCIDA', str(exc))
                tracker.state = 'unknown'
                tracker.pending = None
                tracker.count = 0
                return jsonify(ok=False, error=str(exc), timing=timing), 400

    @app.post('/api/map/tracking/movement/log')
    def tracking_movement_log():
        with lock:
            tracker = state['tracker']
            if tracker is None:
                return jsonify(ok=False, error='Inicia el seguimiento.'), 400
            if battle.paused:
                return jsonify(ok=False, error='Movimiento de ruta pausado mientras Battle está activo.'), 409

            data = request.get_json() or {}
            direction = str(data.get('direction', '')).strip()
            if direction not in {'Norte', 'Sur', 'Este', 'Oeste'}:
                return jsonify(ok=False, error='Dirección inválida.'), 400

            mode = data.get('mode')
            target = data.get('target')
            pending_target = data.get('pending_target')
            target_index = data.get('target_index')
            cycle = data.get('cycle')
            steps = data.get('steps')
            mode_label = 'volver a ruta' if mode == 'return' else 'seguir ruta'
            target_text = f' hacia {target}' if target else ''

            try:
                key = press_direction(direction)
            except Exception as exc:
                tracker.event(
                    'MOVIMIENTO_ERROR',
                    f'No se pudo presionar la flecha para {direction}: {exc}',
                    direction=direction,
                    mode=mode,
                    target=target,
                    error=str(exc),
                )
                return jsonify(ok=False, error=f'No se pudo presionar la tecla: {exc}'), 500

            tracker.event(
                'MOVIMIENTO_TECLA',
                f'Se presionó flecha {direction} ({key}) para {mode_label}{target_text}.',
                direction=direction,
                key=key,
                mode=mode,
                target=target,
                pending_target=pending_target,
                target_index=target_index,
                cycle=cycle,
                steps=steps,
            )
            return jsonify(ok=True, direction=direction, key=key, mode=mode, target=target)

    @app.post('/api/map/tracking/stop')
    def tracking_stop():
        with lock:
            if state['tracker']:
                state['tracker'].event('FIN', 'Seguimiento detenido.')
            state['tracker'] = None
            state['last_sample_started'] = None
            battle.reset()
        return jsonify(ok=True)
