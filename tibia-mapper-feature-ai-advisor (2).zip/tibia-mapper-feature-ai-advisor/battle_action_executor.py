from __future__ import annotations

from mouse_helpers import click_atack_on_battle
from session_log import log_event


def execute_battle_action(target, settings):
    target_id = str(target.get("target_id") or "")
    name = str(target.get("name") or target_id)
    similarity = float(target.get("similarity") or 0)

    log_event(
        f"BATTLE ACTION | id={target_id} | "
        f"name={name} | similarity={similarity:.4f}"
    )

    result_action = click_atack_on_battle()
    result = {
        "ok": bool(result_action and result_action.get("ok")),
        "target_id": target_id,
        "name": name,
    }

    return result
