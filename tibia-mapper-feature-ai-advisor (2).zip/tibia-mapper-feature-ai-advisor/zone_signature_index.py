"""Pre-process a cropped tibia-map-data zone into a fast visual-position index."""
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

import numpy as np
from PIL import Image

WINDOW = 13
HALF = WINDOW // 2
CENTER_MASK_RADIUS = 2
DEFAULT_BLOCK_SIZE = 8
DEFAULT_PALETTE_LIMIT = 32


def _read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def _write_json(path: Path, value) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def _center_mask() -> np.ndarray:
    mask = np.ones((WINDOW, WINDOW), dtype=bool)
    c = WINDOW // 2
    r = CENTER_MASK_RADIUS
    mask[c-r:c+r+1, c-r:c+r+1] = False
    return mask


def _palette_from_map(rgb: np.ndarray, limit: int = DEFAULT_PALETTE_LIMIT) -> np.ndarray:
    pixels = rgb.reshape(-1, 3)
    colors, counts = np.unique(pixels, axis=0, return_counts=True)
    order = np.argsort(counts)[::-1]
    colors = colors[order]
    if len(colors) > limit:
        colors = colors[:limit]
    return colors.astype(np.uint8)


def quantize_to_palette(rgb: np.ndarray, palette: np.ndarray) -> np.ndarray:
    """Assign every RGB tile to the nearest color from the zone's own map palette."""
    # int16 overflowed when squaring differences above 181 (255^2=65025).
    # int32 keeps Euclidean RGB distances correct for OBS pixels far from a map color.
    source = np.asarray(rgb, dtype=np.int32)
    pal = np.asarray(palette, dtype=np.int32)
    flat = source.reshape(-1, 3)
    result = np.empty(flat.shape[0], dtype=np.uint8)
    for start in range(0, len(flat), 4096):
        chunk = flat[start:start+4096]
        distances = ((chunk[:, None, :] - pal[None, :, :]) ** 2).sum(axis=2)
        result[start:start+len(chunk)] = distances.argmin(axis=1).astype(np.uint8)
    return result.reshape(source.shape[:2])


def _rarity_weights(classes: np.ndarray, palette_size: int) -> np.ndarray:
    counts = np.bincount(classes.reshape(-1), minlength=palette_size).astype(np.float64)
    counts[counts == 0] = 1.0
    frequencies = counts / counts.sum()
    weights = 1.0 / np.sqrt(frequencies)
    weights /= np.mean(weights)
    return weights.astype(np.float32)


def _region_preview(rgb: np.ndarray, block_size: int) -> Image.Image:
    """Create a debug preview where each macro-region has a stable overlay color."""
    h, w = rgb.shape[:2]
    base = Image.fromarray(rgb, "RGB").convert("RGBA")
    overlay = np.zeros((h, w, 4), dtype=np.uint8)
    palette = np.array([
        [239, 68, 68], [59, 130, 246], [34, 197, 94], [234, 179, 8],
        [168, 85, 247], [236, 72, 153], [20, 184, 166], [249, 115, 22],
        [99, 102, 241], [132, 204, 22], [14, 165, 233], [244, 63, 94],
    ], dtype=np.uint8)
    index = 0
    for y in range(0, h, block_size):
        for x in range(0, w, block_size):
            color = palette[index % len(palette)]
            overlay[y:min(y+block_size, h), x:min(x+block_size, w), :3] = color
            overlay[y:min(y+block_size, h), x:min(x+block_size, w), 3] = 55
            index += 1
    preview = Image.alpha_composite(base, Image.fromarray(overlay, "RGBA"))
    return preview.convert("RGB")


def build_zone_index(floor_dir: Path, *, block_size: int = DEFAULT_BLOCK_SIZE, palette_limit: int = DEFAULT_PALETTE_LIMIT) -> dict:
    floor_dir = Path(floor_dir).resolve()
    map_path = floor_dir / "map.png"
    zone_path = floor_dir.parent.parent / "zone.json"
    if not map_path.is_file():
        raise FileNotFoundError(f"No existe {map_path}")
    if not zone_path.is_file():
        raise FileNotFoundError(f"No existe {zone_path}")

    zone = _read_json(zone_path)
    left, top, right, bottom = map(int, zone["bbox"])
    with Image.open(map_path) as image:
        rgb = np.asarray(image.convert("RGB"), dtype=np.uint8)
    expected = (right-left+1, bottom-top+1)
    if (rgb.shape[1], rgb.shape[0]) != expected:
        raise ValueError(f"map.png mide {(rgb.shape[1], rgb.shape[0])}, pero zone.json indica {expected}")

    palette = _palette_from_map(rgb, palette_limit)
    classes = quantize_to_palette(rgb, palette)
    rarity = _rarity_weights(classes, len(palette))
    mask = _center_mask()

    positions = []
    signatures = []
    for y in range(HALF, rgb.shape[0]-HALF):
        for x in range(HALF, rgb.shape[1]-HALF):
            patch = classes[y-HALF:y+HALF+1, x-HALF:x+HALF+1]
            positions.append((left+x, top+y))
            signatures.append(patch[mask])

    if not positions:
        raise ValueError("La zona es demasiado pequeña para firmas 13x13.")

    positions_array = np.asarray(positions, dtype=np.int32)
    signatures_array = np.asarray(signatures, dtype=np.uint8)
    npz_path = floor_dir / "locator-index.npz"
    np.savez_compressed(
        npz_path,
        palette=palette,
        classes=classes,
        rarity=rarity,
        positions=positions_array,
        signatures=signatures_array,
        bbox=np.asarray([left, top, right, bottom], dtype=np.int32),
    )

    preview_path = floor_dir / "locator-regions.png"
    _region_preview(rgb, block_size).save(preview_path)

    metadata = {
        "version": 2,
        "source": str(map_path),
        "zone": zone.get("id"),
        "bbox": [left, top, right, bottom],
        "width": int(rgb.shape[1]),
        "height": int(rgb.shape[0]),
        "window": WINDOW,
        "center_mask": "5x5",
        "block_size": block_size,
        "palette_size": int(len(palette)),
        "palette": palette.tolist(),
        "candidate_positions": int(len(positions_array)),
        "files": {"index": npz_path.name, "regions_preview": preview_path.name},
    }
    _write_json(floor_dir / "locator-index.json", metadata)
    return metadata


@dataclass
class ZoneIndex:
    floor_dir: Path
    palette: np.ndarray
    rarity: np.ndarray
    positions: np.ndarray
    signatures: np.ndarray
    bbox: tuple[int, int, int, int]

    @classmethod
    def load(cls, floor_dir: Path, *, build_if_missing: bool = True) -> "ZoneIndex":
        floor_dir = Path(floor_dir).resolve()
        index_path = floor_dir / "locator-index.npz"
        if build_if_missing and not index_path.is_file():
            build_zone_index(floor_dir)
        with np.load(index_path, allow_pickle=False) as data:
            return cls(
                floor_dir=floor_dir,
                palette=data["palette"].copy(),
                rarity=data["rarity"].copy(),
                positions=data["positions"].copy(),
                signatures=data["signatures"].copy(),
                bbox=tuple(int(v) for v in data["bbox"]),
            )

    def contains(self, world_position) -> bool:
        x, y = map(int, world_position)
        left, top, right, bottom = self.bbox
        return left <= x <= right and top <= y <= bottom

    def _obs_signature(self, grid_rgb: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        grid = np.asarray(grid_rgb, dtype=np.uint8)
        if grid.shape != (WINDOW, WINDOW, 3):
            raise ValueError("La grilla OBS debe medir 13x13x3.")
        classes = quantize_to_palette(grid, self.palette)
        signature = classes[_center_mask()]
        weights = self.rarity[signature]
        return signature, weights

    def _scores(self, grid_rgb: np.ndarray, signatures: np.ndarray | None = None) -> np.ndarray:
        signature, weights = self._obs_signature(grid_rgb)
        signatures = self.signatures if signatures is None else signatures
        matches = signatures == signature[None, :]
        return (matches * weights[None, :]).sum(axis=1) / max(float(weights.sum()), 1e-9)

    def score_position(self, grid_rgb: np.ndarray, world_position) -> float:
        target = np.asarray(tuple(map(int, world_position)), dtype=np.int32)
        matches = np.all(self.positions == target[None, :], axis=1)
        if not np.any(matches):
            raise ValueError(f"La posición {tuple(target.tolist())} no tiene firma 13x13 dentro de esta zona.")
        idx = int(np.flatnonzero(matches)[0])
        score = self._scores(grid_rgb, self.signatures[idx:idx+1])[0]
        return round(float(score), 4)

    def locate(self, grid_rgb: np.ndarray, *, near=None, max_distance: int | None = 10, top_k: int = 5) -> tuple[tuple[int, int], float, float, list[dict]]:
        positions = self.positions
        signatures = self.signatures
        if near is not None and max_distance is not None:
            near = np.asarray(near, dtype=np.int32)
            distance = np.max(np.abs(positions - near[None, :]), axis=1)
            keep = distance <= int(max_distance)
            if np.any(keep):
                positions = positions[keep]
                signatures = signatures[keep]

        scores = self._scores(grid_rgb, signatures)

        if near is not None:
            distance = np.max(np.abs(positions - np.asarray(near, dtype=np.int32)[None, :]), axis=1)
            combined = scores - np.minimum(distance, 20) * 0.002
        else:
            combined = scores

        order = np.argsort(combined)[::-1]
        best = int(order[0])
        second = int(order[1]) if len(order) > 1 else best
        gap = float(combined[best] - combined[second]) if len(order) > 1 else 1.0
        top = []
        for idx in order[:max(1, top_k)]:
            top.append({
                "position": [int(positions[idx, 0]), int(positions[idx, 1])],
                "score": round(float(scores[idx]), 4),
                "combined": round(float(combined[idx]), 4),
            })
        return (
            (int(positions[best, 0]), int(positions[best, 1])),
            round(float(scores[best]), 4),
            round(gap, 4),
            top,
        )


def targuna_floor_07(root: Path) -> Path:
    return Path(root) / "data" / "tibia-map-zones" / "thais" / "targuna" / "floors" / "07"
