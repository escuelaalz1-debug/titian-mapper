"""World-coordinate route plans, kept apart from executable screen routines."""
import json
import uuid
from datetime import datetime
from app_paths import RUNTIME_ROOT

MAP_ROUTINES_DIR = RUNTIME_ROOT / 'routines' / 'map'


def list_map_routines():
    if not MAP_ROUTINES_DIR.exists():
        return []
    return [json.loads(path.read_text(encoding='utf-8'))
            for path in sorted(MAP_ROUTINES_DIR.glob('*.json'))]


def create_map_routine(payload, zones):
    if not isinstance(payload, dict):
        raise ValueError('Datos de rutina inválidos.')
    name = payload.get('name')
    if not isinstance(name, str) or not name.strip() or len(name.strip()) > 100:
        raise ValueError('Escribe un nombre de hasta 100 caracteres.')
    points = payload.get('points')
    if not isinstance(points, list) or not 1 <= len(points) <= 1000:
        raise ValueError('La rutina debe tener entre 1 y 1000 puntos.')
    catalog = {zone['id']: zone for zone in zones}
    normalized = []
    for point in points:
        if not isinstance(point, dict):
            raise ValueError('Punto inválido.')
        zone = catalog.get(str(point.get('zone_id', '')))
        if zone is None:
            raise ValueError('La zona de un punto no está disponible.')
        if any(type(point.get(key)) is not int for key in ('x', 'y', 'z')):
            raise ValueError('Las coordenadas deben ser enteros.')
        x, y, z = point['x'], point['y'], point['z']
        left, top, right, bottom = zone['bbox']
        if not (left <= x <= right and top <= y <= bottom and z in zone['floors']):
            raise ValueError('Hay un punto fuera de su zona o piso.')
        normalized.append({'x': x, 'y': y, 'z': z, 'zone_id': zone['id']})
    for index, point in enumerate(normalized):
        previous = normalized[index-1] if index else None
        point['selection_mode'] = ('start' if previous is None else
            'floor_transition' if previous['z'] != point['z'] else
            'minimap' if abs(previous['x']-point['x']) > 7 or abs(previous['y']-point['y']) > 5 else 'screen')
    data = {'id': uuid.uuid4().hex, 'name': name.strip(), 'type': 'map_route',
            'coordinate_system': 'tibia_world', 'points': normalized,
            'visibility': {'horizontal_radius': 7, 'vertical_radius': 5},
            'created_at': datetime.now().isoformat(timespec='seconds')}
    MAP_ROUTINES_DIR.mkdir(parents=True, exist_ok=True)
    with (MAP_ROUTINES_DIR / (data['id'] + '.json')).open('x', encoding='utf-8') as file:
        json.dump(data, file, ensure_ascii=False, indent=2)
    return data
