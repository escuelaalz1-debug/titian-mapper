"""Passive minimap tracking and same-floor route recovery. Never sends input."""
import json
from collections import deque
from datetime import datetime

import cv2
import numpy as np
from PIL import Image
from app_paths import RUNTIME_ROOT
import tibia_map_service as maps
from tibia_map_zones import pathfinding_file

MINIMAP_TILES = 13
CENTER_MASK_RADIUS = 2
RELATIVE_MAX_STEP = 5
RELATIVE_MIN_SCORE = .56
RELATIVE_MIN_GAP = .012
LONG_MOVE_MIN_SCORE = {1: .56, 2: .72, 3: .82, 4: .90, 5: .94}
LONG_MOVE_MIN_GAP = {1: .012, 2: .03, 3: .06, 4: .10, 5: .10}

LOCAL_SEARCH_RADIUS = 6
LOCAL_MIN_MAP_SCORE = .46
LOCAL_MIN_GAP = .010
LOCAL_TOP_K = 3


def shortest_path(walkable, start, goals, max_nodes=150000):
    """Four-way search: no diagonal corner cutting or unknown terrain."""
    goals = set(goals)
    height, width = walkable.shape

    def valid(p):
        return 0 <= p[0] < width and 0 <= p[1] < height and walkable[p[1], p[0]]

    if not valid(start):
        raise ValueError('La posición detectada no es transitable en el mapa local.')
    goals = {g for g in goals if valid(g)}
    if not goals:
        raise ValueError('No hay puntos transitables de retorno.')
    queue = deque([start])
    parents = {start: None}
    while queue:
        p = queue.popleft()
        if p in goals:
            path = []
            while p is not None:
                path.append(p)
                p = parents[p]
            return path[::-1]
        if len(parents) > max_nodes:
            raise ValueError('Búsqueda demasiado extensa; usa una ruta más próxima.')
        for q in ((p[0] + 1, p[1]), (p[0] - 1, p[1]), (p[0], p[1] + 1), (p[0], p[1] - 1)):
            if q not in parents and valid(q):
                parents[q] = p
                queue.append(q)
    raise ValueError('No hay un camino transitable hasta la ruta en este piso.')


def locate(world, template, threshold=.92, gap=.025):
    """Legacy global matcher kept for diagnostics/tests."""
    h, w = template.shape[:2]
    if h < 15 or w < 15 or h > world.shape[0] or w > world.shape[1]:
        raise ValueError('Recorte o escala inválidos: se necesitan al menos 15 × 15 cuadros.')
    if float(template.std()) < 8:
        raise ValueError('El minimapa no tiene suficiente detalle para localizarte.')
    mask = np.ones(template.shape, dtype=np.uint8) * 255
    mask[max(0, h // 2 - 3):h // 2 + 4, max(0, w // 2 - 3):w // 2 + 4] = 0
    scores = cv2.matchTemplate(world, template, cv2.TM_SQDIFF_NORMED, mask=mask)
    scores = np.nan_to_num(scores, nan=1, posinf=1, neginf=1)
    _, _, point, _ = cv2.minMaxLoc(scores)
    error = float(scores[point[1], point[0]])
    scores[max(0, point[1] - 3):point[1] + 4, max(0, point[0] - 3):point[0] + 4] = 1
    second = float(scores.min())
    if 1 - error < threshold or second - error < gap:
        raise ValueError(f'Posición desconocida: coincidencia {1-error:.1%}, separación {second-error:.3f}. Revisa recorte, escala y piso.')
    return (point[0] + w // 2, point[1] + h // 2), round(1 - error, 4)


def detect_minimap_calibration(image):
    """Estimate the player-cross center and initial tile pitch from the minimap capture."""
    rgb = np.asarray(image.convert('RGB'), dtype=np.uint8)
    h, w = rgb.shape[:2]
    if min(w, h) < 40:
        raise ValueError('La captura del minimapa es demasiado pequeña para calibrar.')

    x0, x1 = w // 4, (w * 3) // 4
    y0, y1 = h // 4, (h * 3) // 4
    center = rgb[y0:y1, x0:x1]
    maximum = center.max(axis=2)
    minimum = center.min(axis=2)
    white = (minimum >= 205) & ((maximum - minimum) <= 38)

    ys, xs = np.where(white)
    detected = len(xs) >= 6
    if detected:
        cx = float(np.median(xs + x0))
        cy = float(np.median(ys + y0))
    else:
        cx = (w - 1) / 2.0
        cy = (h - 1) / 2.0

    half_tiles = MINIMAP_TILES // 2 + .5
    available_x = 2.0 * min(cx + .5, w - .5 - cx)
    available_y = 2.0 * min(cy + .5, h - .5 - cy)
    tile_w = max(1.0, available_x / MINIMAP_TILES)
    tile_h = max(1.0, available_y / MINIMAP_TILES)

    return {
        'center_x': round(cx, 2),
        'center_y': round(cy, 2),
        'tile_width': round(tile_w, 3),
        'tile_height': round(tile_h, 3),
        'cross_detected': bool(detected),
        'image_width': int(w),
        'image_height': int(h),
        'visible_tiles': MINIMAP_TILES,
        'half_tiles': half_tiles,
    }


def sample_minimap_grid(image, calibration=None):
    """Read one representative RGB value per real minimap tile using calibrated geometry."""
    if image.width < MINIMAP_TILES or image.height < MINIMAP_TILES:
        raise ValueError('El recorte del minimapa es demasiado pequeño.')

    calibration = calibration or detect_minimap_calibration(image)
    cx = float(calibration['center_x'])
    cy = float(calibration['center_y'])
    tile_w = float(calibration['tile_width'])
    tile_h = float(calibration['tile_height'])
    if tile_w <= 1 or tile_h <= 1:
        raise ValueError('La calibración del tamaño de cuadro es inválida.')

    rgb = np.asarray(image.convert('RGB'), dtype=np.uint8)
    h, w = rgb.shape[:2]
    grid = np.zeros((MINIMAP_TILES, MINIMAP_TILES, 3), dtype=np.uint8)
    sample_rx = max(1, int(round(tile_w * .16)))
    sample_ry = max(1, int(round(tile_h * .16)))
    half = MINIMAP_TILES // 2

    for gy in range(MINIMAP_TILES):
        for gx in range(MINIMAP_TILES):
            px = cx + (gx - half) * tile_w
            py = cy + (gy - half) * tile_h
            ix = int(round(px))
            iy = int(round(py))
            if ix < 0 or iy < 0 or ix >= w or iy >= h:
                raise ValueError('La grilla calibrada sale del área capturada. Ajusta centro o tamaño de cuadro.')
            sx0, sx1 = max(0, ix - sample_rx), min(w, ix + sample_rx + 1)
            sy0, sy1 = max(0, iy - sample_ry), min(h, iy + sample_ry + 1)
            patch = rgb[sy0:sy1, sx0:sx1]
            grid[gy, gx] = np.median(patch.reshape(-1, 3), axis=0).astype(np.uint8)
    return grid


def minimap_grid(image):
    """Backward-compatible helper using automatic geometry calibration."""
    return sample_minimap_grid(image, detect_minimap_calibration(image))


def _center_mask(shape=(MINIMAP_TILES, MINIMAP_TILES)):
    mask = np.ones(shape, dtype=bool)
    c = MINIMAP_TILES // 2
    r = CENTER_MASK_RADIUS
    mask[max(0, c-r):c+r+1, max(0, c-r):c+r+1] = False
    return mask


def _score_pixels(a, b, mask):
    values = np.abs(a.astype(np.int16) - b.astype(np.int16)).mean(axis=2)[mask]
    if values.size < 20:
        return 0.0
    close = float(np.mean(values <= 55.0))
    color = 1.0 - float(np.mean(np.minimum(values, 255.0))) / 255.0
    return 0.76 * close + 0.24 * color


def _coarse_colors(rgb):
    """Map RGB tiles to stable color families so OBS compression/blur matters less."""
    hsv = cv2.cvtColor(np.asarray(rgb, dtype=np.uint8), cv2.COLOR_RGB2HSV)
    hue, sat, val = hsv[:, :, 0], hsv[:, :, 1], hsv[:, :, 2]
    result = np.full(hue.shape, 8, dtype=np.uint8)

    result[val < 45] = 0  # black/dark
    neutral = (sat < 45) & (val >= 45)
    result[neutral & (val < 215)] = 1  # gray
    result[neutral & (val >= 215)] = 2  # white

    colored = (sat >= 45) & (val >= 45)
    result[colored & ((hue < 10) | (hue >= 170))] = 3  # red
    result[colored & (hue >= 10) & (hue < 35)] = 4  # orange/yellow
    result[colored & (hue >= 35) & (hue < 90)] = 5  # green
    result[colored & (hue >= 90) & (hue < 135)] = 6  # cyan/blue
    result[colored & (hue >= 135) & (hue < 170)] = 7  # purple/magenta
    return result


def _patch_score(template, patch):
    """Hybrid map score: color family is primary, tolerant RGB is secondary."""
    mask = _center_mask()
    categories_a = _coarse_colors(template)
    categories_b = _coarse_colors(patch)
    category_score = float(np.mean((categories_a == categories_b)[mask]))
    rgb_score = _score_pixels(template, patch, mask)
    return 0.72 * category_score + 0.28 * rgb_score


def _relative_score(previous, current, dx, dy):
    """Score a player movement. Positive dx means east; positive dy means south."""
    n = MINIMAP_TILES
    px0, px1 = max(0, dx), min(n, n + dx)
    py0, py1 = max(0, dy), min(n, n + dy)
    cx0, cx1 = max(0, -dx), min(n, n - dx)
    cy0, cy1 = max(0, -dy), min(n, n - dy)
    if px1 <= px0 or py1 <= py0:
        return 0.0

    prev = previous[py0:py1, px0:px1]
    curr = current[cy0:cy1, cx0:cx1]
    prev_y, prev_x = np.mgrid[py0:py1, px0:px1]
    curr_y, curr_x = np.mgrid[cy0:cy1, cx0:cx1]
    c = n // 2
    r = CENTER_MASK_RADIUS
    prev_center = (np.abs(prev_x-c) <= r) & (np.abs(prev_y-c) <= r)
    curr_center = (np.abs(curr_x-c) <= r) & (np.abs(curr_y-c) <= r)
    mask = ~(prev_center | curr_center)
    return _score_pixels(prev, curr, mask)


def _movement_requirements(distance):
    if distance <= 0:
        return RELATIVE_MIN_SCORE, 0.0
    distance = min(distance, RELATIVE_MAX_STEP)
    return LONG_MOVE_MIN_SCORE.get(distance, .94), LONG_MOVE_MIN_GAP.get(distance, .10)


def detect_relative_move(previous, current, max_step=RELATIVE_MAX_STEP):
    """Infer movement between consecutive minimaps. Used only as a soft prior now."""
    if previous.shape[:2] != (MINIMAP_TILES, MINIMAP_TILES) or current.shape[:2] != (MINIMAP_TILES, MINIMAP_TILES):
        raise ValueError('Las referencias del minimapa deben ser de 13 × 13 cuadros.')
    candidates = []
    for dy in range(-max_step, max_step + 1):
        for dx in range(-max_step, max_step + 1):
            raw = _relative_score(previous, current, dx, dy)
            distance = max(abs(dx), abs(dy))
            adjusted = raw - distance * .004
            candidates.append((adjusted, raw, dx, dy))
    candidates.sort(reverse=True, key=lambda item: item[0])
    best_adjusted, best, dx, dy = candidates[0]
    second = candidates[1][0] if len(candidates) > 1 else -1.0
    gap = best_adjusted - second
    movement = max(abs(dx), abs(dy))
    required_score, required_gap = _movement_requirements(movement)
    if best < required_score:
        raise ValueError(
            f'Movimiento no validado entre capturas: {movement} cuadro(s), coincidencia {best:.1%}; '
            f'se requiere {required_score:.1%}.'
        )
    if movement and gap < required_gap:
        raise ValueError(
            f'Movimiento ambiguo entre capturas: {movement} cuadro(s), coincidencia {best:.1%}, '
            f'separación {gap:.3f}; se requiere {required_gap:.3f}.'
        )
    return (dx, dy), round(best, 4), round(gap, 4)


def localize_near(world, walkable, grid, center, expected=None, radius=LOCAL_SEARCH_RADIUS, top_k=LOCAL_TOP_K):
    """Find the absolute current coordinate in a small neighborhood around the last known position."""
    half = MINIMAP_TILES // 2
    h, w = walkable.shape
    candidates = []

    for y in range(max(half, center[1] - radius), min(h - half, center[1] + radius + 1)):
        for x in range(max(half, center[0] - radius), min(w - half, center[0] + radius + 1)):
            if not walkable[y, x]:
                continue
            patch = world[y-half:y+half+1, x-half:x+half+1]
            if patch.shape[:2] != (MINIMAP_TILES, MINIMAP_TILES):
                continue
            map_score = _patch_score(grid, patch)
            distance = max(abs(x-center[0]), abs(y-center[1]))
            combined = map_score - distance * .003
            if expected is not None:
                expected_distance = max(abs(x-expected[0]), abs(y-expected[1]))
                combined -= expected_distance * .008
            candidates.append((combined, map_score, x, y))

    if not candidates:
        raise ValueError('No hay posiciones transitables candidatas cerca de la última ubicación.')

    candidates.sort(reverse=True, key=lambda item: item[0])
    best_combined, best_map_score, best_x, best_y = candidates[0]
    second_combined = candidates[1][0] if len(candidates) > 1 else -1.0
    gap = best_combined - second_combined

    if best_map_score < LOCAL_MIN_MAP_SCORE:
        raise ValueError(
            f'Localización local débil contra tibia-map-data: coincidencia {best_map_score:.1%}; '
            f'se requiere {LOCAL_MIN_MAP_SCORE:.1%}.'
        )
    if (best_x, best_y) != center and gap < LOCAL_MIN_GAP:
        raise ValueError(
            f'Localización local ambigua: coincidencia {best_map_score:.1%}, separación {gap:.3f}; '
            f'se requiere {LOCAL_MIN_GAP:.3f}.'
        )

    top = [
        {
            'position': [x, y],
            'map_score': round(score, 4),
            'combined': round(combined, 4),
        }
        for combined, score, x, y in candidates[:top_k]
    ]
    return (best_x, best_y), round(best_map_score, 4), round(gap, 4), top


def _routine_context(routine):
    points = routine['points']
    if not points or len({p['z'] for p in points}) != 1:
        raise ValueError('Selecciona una rutina de un solo piso para esta prueba de seguimiento.')
    z = points[0]['z']
    bounds = maps._load_bounds()
    origin = (int(bounds['xMin']), int(bounds['yMin']))
    with Image.open(maps._floor_map_path(z)) as image:
        world = np.asarray(image.convert('RGB'))
    with Image.open(pathfinding_file(maps.MAP_DATA_ROOT, z)) as image:
        costs = np.asarray(image.convert('RGB'))
    walkable = (costs[:, :, 0] == costs[:, :, 1]) & (costs[:, :, 1] == costs[:, :, 2])
    pixels = [(p['x'] - origin[0], p['y'] - origin[1]) for p in points]
    plan = [pixels[0]]
    for a, b in zip(pixels, pixels[1:]):
        plan.extend(shortest_path(walkable, a, [b])[1:])
    return z, origin, world, walkable, plan


class Tracker:
    @classmethod
    def prepare(cls, routine):
        z, origin, _, _, plan = _routine_context(routine)
        return {
            'z': z,
            'origin': list(origin),
            'plan': [[x + origin[0], y + origin[1]] for x, y in plan],
        }

    def __init__(self, routine, config):
        self.z, self.origin, self.world, self.walkable, self.plan = _routine_context(routine)
        self.region = {k: int(config[k]) for k in ('x', 'y', 'width', 'height')}
        if self.region['x'] < 0 or self.region['y'] < 0 or min(self.region['width'], self.region['height']) < 13 or max(self.region['width'], self.region['height']) > 2000:
            raise ValueError('Selecciona el interior del minimapa en la captura.')

        self.calibration = {
            'center_x': float(config.get('center_x', self.region['width'] / 2.0)),
            'center_y': float(config.get('center_y', self.region['height'] / 2.0)),
            'tile_width': float(config.get('tile_width', self.region['width'] / MINIMAP_TILES)),
            'tile_height': float(config.get('tile_height', self.region['height'] / MINIMAP_TILES)),
        }
        if self.calibration['tile_width'] <= 1 or self.calibration['tile_height'] <= 1:
            raise ValueError('Calibra el minimapa antes de iniciar el seguimiento.')

        initial_world = (int(config['initial_x']), int(config['initial_y']))
        initial = (initial_world[0] - self.origin[0], initial_world[1] - self.origin[1])
        h, w = self.walkable.shape
        if not (0 <= initial[0] < w and 0 <= initial[1] < h):
            raise ValueError('La posición inicial marcada queda fuera del mapa de este piso.')
        if not self.walkable[initial[1], initial[0]]:
            raise ValueError('La posición inicial marcada no es transitable en el mapa local.')

        self.progress = 0
        self.state = 'unknown'
        self.pending = None
        self.count = 0
        self.was_deviated = False
        self.events = []
        self.trail = [initial]
        self.last = initial
        self.previous_grid = None
        self.log_path = RUNTIME_ROOT / 'logs' / f'map-tracking-{datetime.now():%Y%m%d-%H%M%S-%f}.jsonl'
        self.log_path.parent.mkdir(exist_ok=True)
        self.event(
            'INICIO',
            'Seguimiento por localización absoluta local iniciado desde posición marcada manualmente.',
            position=list(initial_world),
            calibration=self.calibration,
            search_radius=LOCAL_SEARCH_RADIUS,
        )

    def world_points(self, points):
        return [[x + self.origin[0], y + self.origin[1]] for x, y in points]

    def event(self, kind, message, **extra):
        event = {'time': datetime.now().isoformat(timespec='seconds'), 'kind': kind, 'message': message, **extra}
        self.events.append(event)
        self.events = self.events[-100:]
        with self.log_path.open('a', encoding='utf-8') as file:
            file.write(json.dumps(event, ensure_ascii=False) + '\n')

    def _unknown(self, message, candidates=None):
        if self.state != 'unknown':
            self.event('POSICION_DESCONOCIDA', message, last_known=self.world_points([self.last])[0], candidates=candidates or [])
        self.state = 'unknown'
        self.pending = None
        self.count = 0
        return {
            'state': 'unknown',
            'message': message,
            'events': self.events,
            'return_path': [],
            'position': self.world_points([self.last])[0],
            'position_stale': True,
            'trail': self.world_points(self.trail),
            'candidates': candidates or [],
        }

    def sample(self, frame):
        r = self.region
        if r['x'] + r['width'] > frame.width or r['y'] + r['height'] > frame.height:
            raise ValueError('El recorte queda fuera de la captura actual.')
        crop = frame.crop((r['x'], r['y'], r['x'] + r['width'], r['y'] + r['height']))
        grid = sample_minimap_grid(crop, self.calibration)

        if self.previous_grid is None:
            self.previous_grid = grid
            return {
                'state': 'unknown',
                'message': 'Referencia visual guardada. El siguiente muestreo localizará la captura contra tibia-map-data cerca de la posición inicial.',
                'position': self.world_points([self.last])[0],
                'position_stale': False,
                'confidence': 1.0,
                'gap': 1.0,
                'world_confidence': None,
                'delta': [0, 0],
                'relative_delta': [0, 0],
                'relative_confidence': 1.0,
                'return_path': [],
                'trail': self.world_points(self.trail),
                'events': self.events,
                'progress': self.progress,
                'candidates': [],
            }

        previous = self.last
        relative_delta = None
        relative_confidence = None
        relative_gap = None
        expected = None
        try:
            relative_delta, relative_confidence, relative_gap = detect_relative_move(self.previous_grid, grid, max_step=3)
            expected = (previous[0] + relative_delta[0], previous[1] + relative_delta[1])
        except ValueError:
            pass

        # Visual frame always advances. Relative movement is only a hint; absolute map matching is the authority.
        self.previous_grid = grid

        try:
            position, map_score, local_gap, candidates = localize_near(
                self.world,
                self.walkable,
                grid,
                previous,
                expected=expected,
            )
        except ValueError as exc:
            return self._unknown(str(exc))

        dx, dy = position[0] - previous[0], position[1] - previous[1]
        distances = [max(abs(position[0] - p[0]), abs(position[1] - p[1])) for p in self.plan[self.progress:]]
        distance = min(distances)
        nearest = distances.index(distance) + self.progress
        route_candidate = 'on_route' if distance <= 2 else 'deviated'
        if route_candidate == self.pending:
            self.count += 1
        else:
            self.pending = route_candidate
            self.count = 1
        if self.count >= 2 and route_candidate != self.state:
            kind = ('REGRESO' if self.was_deviated else 'LOCALIZADO') if route_candidate == 'on_route' else 'DESVIO'
            self.event(
                kind,
                ('Regreso confirmado a un punto conocido.' if self.was_deviated else 'Posición confirmada sobre la ruta.') if route_candidate == 'on_route' else 'Desvío confirmado; calcula y sigue el regreso indicado.',
                position=self.world_points([position])[0],
                map_score=map_score,
                local_gap=local_gap,
                candidates=candidates,
            )
            self.was_deviated = route_candidate == 'deviated'
            self.state = route_candidate
        if route_candidate == 'on_route' and self.count >= 2:
            self.progress = max(self.progress, nearest)
        if position != self.last:
            self.trail.append(position)
            self.trail = self.trail[-1000:]

        path = []
        message = f'Localización local confirmada contra tibia-map-data ({map_score:.1%}, separación {local_gap:.3f}).'
        if route_candidate == 'deviated':
            try:
                path = shortest_path(self.walkable, position, self.plan[self.progress:])
                if position != self.last:
                    self.event('CAMINO_REGRESO', f'Regreso trazable de {len(path)-1} cuadros.', path=self.world_points(path))
                message += f' Regreso: {len(path)-1} cuadros hasta {self.world_points([path[-1]])[0]}.'
            except ValueError as exc:
                message += ' ' + str(exc)
                if position != self.last:
                    self.event('SIN_CAMINO', str(exc))

        delta = [dx, dy]
        self.last = position
        return {
            'state': self.state,
            'message': message,
            'position': self.world_points([position])[0],
            'position_stale': False,
            'confidence': map_score,
            'gap': local_gap,
            'world_confidence': map_score,
            'delta': delta,
            'relative_delta': list(relative_delta) if relative_delta is not None else None,
            'relative_confidence': relative_confidence,
            'relative_gap': relative_gap,
            'return_path': self.world_points(path),
            'trail': self.world_points(self.trail),
            'events': self.events,
            'progress': self.progress,
            'candidates': [
                {
                    **candidate,
                    'position': self.world_points([tuple(candidate['position'])])[0],
                }
                for candidate in candidates
            ],
        }
