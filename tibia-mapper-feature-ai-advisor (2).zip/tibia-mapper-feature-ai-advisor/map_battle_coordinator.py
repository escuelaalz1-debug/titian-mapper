from __future__ import annotations

from battle_action_executor import execute_battle_action
from battle_monitor import update_battle_runtime
from settings_store import get_settings


class MapBattleCoordinator:
    """Pause route movement while Battle references are being handled."""

    def __init__(self):
        self.paused = False

    def reset(self) -> None:
        self.paused = False

    def _pause_result(self, tracker, battle_state, message: str) -> dict:
        position = tracker.world_points([tracker.last])[0]
        locator_mode = '27x27-global' if getattr(tracker, 'wide_mode', False) else 'legacy-13x13'
        return {
            'state': getattr(tracker, 'state', 'unknown'),
            'route_candidate': getattr(tracker, 'state', 'unknown'),
            'message': message,
            'position': position,
            'position_stale': True,
            'confidence': None,
            'gap': None,
            'world_confidence': None,
            'delta': [0, 0],
            'relative_delta': None,
            'relative_confidence': None,
            'relative_gap': None,
            'return_path': [],
            'trail': [],
            'guidance': None,
            'events': tracker.events,
            'progress': getattr(tracker, 'progress', 0),
            'target_index': getattr(tracker, 'target_index', 0),
            'target_count': len(getattr(tracker, 'route_targets', []) or []),
            'current_target': tracker._target_world() if hasattr(tracker, '_target_world') else None,
            'repeat_routine': bool(getattr(tracker, 'repeat_routine', False)),
            'cycle': int(getattr(tracker, 'cycle_count', 0)) + 1,
            'locator_mode': locator_mode,
            'candidates': [],
            'battle_paused': True,
            'battle_state': battle_state,
        }

    def step(self, tracker) -> dict | None:
        settings = dict(get_settings())
        battle_state = update_battle_runtime(settings)

        if not bool(settings.get('battle_detection_enabled', False)):
            if self.paused:
                self.paused = False
                tracker.event(
                    'BATTLE_REANUDAR_RUTA',
                    'Battle está desactivado; se reanuda el seguimiento de la rutina.',
                )
            return None

        pending = battle_state.get('pending_target')
        if battle_state.get('action_triggered') and pending:
            action_result = execute_battle_action(pending, settings)
            tracker.event(
                'BATTLE_ACCION',
                f"Battle ejecutó acción para {pending.get('name') or pending.get('target_id')}.",
                target_id=pending.get('target_id'),
                similarity=pending.get('similarity'),
                action_ok=bool(action_result.get('ok')),
                trigger_serial=battle_state.get('trigger_serial'),
            )

        scan = battle_state.get('scan') or {}
        matches = list(scan.get('matches') or [])
        active = bool(
            battle_state.get('action_locked')
            or battle_state.get('action_triggered')
            or matches
        )

        if active:
            if not self.paused:
                self.paused = True
                tracker.event(
                    'BATTLE_PAUSA_RUTA',
                    'Referencia Battle detectada; se pausa el movimiento de la rutina hasta limpiar Battle.',
                    target_id=(pending or {}).get('target_id'),
                    target_name=(pending or {}).get('name'),
                    similarity=(pending or {}).get('similarity'),
                )
            target_name = (pending or {}).get('name') or (pending or {}).get('target_id') or 'referencia'
            return self._pause_result(
                tracker,
                battle_state,
                f'Battle activo con {target_name}; seguimiento de ruta pausado.',
            )

        # Al liberar un objetivo, el scan de esa misma iteración todavía corresponde
        # al seguimiento del Battle anterior. Exigimos un scan idle posterior y limpio
        # antes de permitir otra tecla de movimiento de ruta.
        if self.paused and (battle_state.get('released') or battle_state.get('busy')):
            reason = battle_state.get('release_reason') or 'verificando referencias restantes'
            return self._pause_result(
                tracker,
                battle_state,
                f'Battle liberado ({reason}); verificando que no queden referencias antes de reanudar.',
            )

        if self.paused:
            self.paused = False
            tracker.event(
                'BATTLE_REANUDAR_RUTA',
                'No quedan referencias Battle detectadas; se reanuda la rutina desde la última posición confirmada.',
            )

        return None
