from __future__ import annotations

import argparse
import json
from pathlib import Path

from app_paths import RUNTIME_ROOT
from zone_signature_index import build_zone_index, targuna_floor_07


def main() -> int:
    parser = argparse.ArgumentParser(description="Preprocesa un map.png de tibia-map-zones para localización visual.")
    parser.add_argument(
        "floor_dir",
        nargs="?",
        type=Path,
        default=targuna_floor_07(RUNTIME_ROOT),
        help="Carpeta que contiene map.png. Por defecto: thais/targuna/floors/07",
    )
    parser.add_argument("--block-size", type=int, default=8, help="Tamaño de macrozonas del preview.")
    parser.add_argument("--palette-limit", type=int, default=32, help="Máximo de colores del mapa usados como clases.")
    args = parser.parse_args()

    metadata = build_zone_index(args.floor_dir, block_size=args.block_size, palette_limit=args.palette_limit)
    print(json.dumps(metadata, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
