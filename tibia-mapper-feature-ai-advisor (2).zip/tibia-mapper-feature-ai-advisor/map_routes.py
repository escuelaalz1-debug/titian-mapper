from __future__ import annotations

from flask import abort, jsonify, render_template, request, send_file
import tibia_map_service as map_service
from map_routine_store import create_map_routine, list_map_routines

from tibia_map_service import get_position_info, list_map_zones, map_data_status


def register_map_routes(app) -> None:
    from map_tracking_routes import register_tracking_routes
    register_tracking_routes(app)
    @app.get("/api/map/routines")
    def map_routines_list():
        return jsonify({"ok": True, "routines": list_map_routines()})

    @app.post("/api/map/routines")
    def map_routines_create():
        try:
            routine = create_map_routine(request.get_json(silent=True), list_map_zones())
        except (ValueError, TypeError) as exc:
            return jsonify({"ok": False, "error": str(exc)}), 400
        return jsonify({"ok": True, "routine": routine}), 201

    @app.get("/maps")
    def maps_view():
        return render_template("maps.html")

    @app.get("/api/map/zones/<zone_id>/floors/<int:floor>/<layer>")
    def zone_asset(zone_id, floor, layer):
        filenames = {"map": "map.png", "pathfinding": "pathfinding.png", "markers": "markers.json"}
        if layer not in filenames:
            abort(404)
        zone = next((z for z in list_map_zones() if z["id"] == zone_id), None)
        if zone is None or floor not in zone["floors"]:
            abort(404)
        root = map_service.MAP_ZONES_ROOT.resolve()
        path = (root / zone["path"] / "floors" / f"{floor:02d}" / filenames[layer]).resolve()
        if not path.is_relative_to(root) or not path.is_file():
            abort(404)
        return send_file(path, conditional=True, max_age=0)

    @app.get("/api/map/zones")
    def map_zones():
        try:
            zones = list_map_zones()
        except (ValueError, OSError) as exc:
            return jsonify({"ok": False, "error": str(exc)}), 400
        area = request.args.get("area")
        if area:
            zones = [zone for zone in zones if zone["area"].casefold() == area.casefold()]
        return jsonify({"ok": True, "zones": zones})

    @app.get("/api/map/status")
    def map_status():
        return jsonify({"ok": True, "map": map_data_status()})

    @app.get("/api/map/position")
    def map_position():
        try:
            x = int(request.args.get("x"))
            y = int(request.args.get("y"))
            z = int(request.args.get("z"))
            radius = float(request.args.get("marker_radius", 30.0))
            info = get_position_info(x, y, z, marker_radius=max(0.0, min(500.0, radius)))
        except (TypeError, ValueError, FileNotFoundError, OSError) as exc:
            return jsonify({"ok": False, "error": str(exc), "map": map_data_status()}), 400
        return jsonify({"ok": True, "map": info})
