"""Read OBS sources/scenes through obs-websocket 5; never capture the desktop."""
import base64
import hashlib
import io
import json
from PIL import Image


def _capture_obs_source(source_name, port=4455, password=''):
    import websocket
    if not isinstance(source_name, str) or not source_name.strip():
        raise ValueError('Indica el nombre de la fuente o escena OBS.')
    if not 1 <= int(port) <= 65535:
        raise ValueError('Puerto OBS inválido.')
    try:
        connection = websocket.create_connection(f'ws://127.0.0.1:{int(port)}', timeout=8)
    except Exception as exc:
        raise RuntimeError('No se pudo conectar a OBS. Activa el servidor WebSocket en Herramientas de OBS y comprueba el puerto.') from exc
    try:
        hello = json.loads(connection.recv())
        if hello.get('op') != 0:
            raise RuntimeError('OBS no respondió con el protocolo WebSocket 5.')
        identify = {'rpcVersion': 1, 'eventSubscriptions': 0}
        auth = hello['d'].get('authentication')
        if auth:
            secret = base64.b64encode(hashlib.sha256((password + auth['salt']).encode()).digest()).decode()
            identify['authentication'] = base64.b64encode(hashlib.sha256((secret + auth['challenge']).encode()).digest()).decode()
        connection.send(json.dumps({'op': 1, 'd': identify}))
        try:
            identified = json.loads(connection.recv())
        except Exception as exc:
            raise RuntimeError('OBS rechazó la conexión. Comprueba la contraseña WebSocket.') from exc
        if identified.get('op') != 2:
            raise RuntimeError('No se pudo autenticar con OBS.')
        connection.send(json.dumps({
            'op': 6,
            'd': {
                'requestType': 'GetSourceScreenshot',
                'requestId': 'source-capture',
                'requestData': {'sourceName': source_name.strip(), 'imageFormat': 'png'}
            }
        }))
        response = json.loads(connection.recv())
        data = response.get('d', {})
        if response.get('op') != 7 or not data.get('requestStatus', {}).get('result'):
            raise RuntimeError(f'OBS no pudo capturar "{source_name}". Comprueba que exista con ese nombre exacto y tenga fuentes activas.')
        encoded = data['responseData']['imageData']
        if not encoded.startswith('data:image/png;base64,'):
            raise RuntimeError('OBS no devolvió una imagen PNG.')
        with Image.open(io.BytesIO(base64.b64decode(encoded.split(',', 1)[1], validate=True))) as image:
            return image.convert('RGB')
    finally:
        connection.close()


def capture_source(source='Mapa', port=4455, password=''):
    """Capture one OBS source directly (preferred for the minimap)."""
    return _capture_obs_source(source, port=port, password=password)


def capture_scene(scene='PanelDatos', port=4455, password=''):
    """Backward-compatible scene capture."""
    return _capture_obs_source(scene, port=port, password=password)
