"""Targuna multi-floor 27x27 tracker trial.

Floor 07 keeps using the proven implementation from ``map_tracking_wide``.
Floor 08 is enabled here as the first validation that the same absolute 27x27
locator can be reused on another floor before generalizing it to every zone.
"""
from __future__ import annotations

from pathlib import Path

from app_paths import RUNTIME_ROOT
from map_tracking_wide import Tracker as Floor07Tracker, _default_calibration
from zone_signature_index import ZoneIndex, build_zone_index
from zone_wide_locator import WideCalibration, WideZoneLocator

TRIAL_WIDE_FLOORS = {8}


def targuna_floor_dir(root: Path, z: int) -> Path:
    z = int(z)
    if not 0 <= z <= 15:
        raise ValueError(f'Piso inválido: {z}')
    return Path(root) / 'data' / 'tibia-map-zones' / 'thais' / 'targuna' / 'floors' / f'{z:02d}'


def _enable_floor08_wide(tracker, config) -> None:
    initial_world = (int(config['initial_x']), int(config['initial_y']))
    floor_dir = targuna_floor_dir(RUNTIME_ROOT, tracker.z)

    build_zone_index(floor_dir)
    index = ZoneIndex.load(floor_dir, build_if_missing=False)
    locator = WideZoneLocator(index, floor_dir)
    # This also proves the selected initial coordinate has enough 27x27 context.
    locator.expected_signature(initial_world)

    tracker.wide_mode = True
    tracker.wide_floor_dir = floor_dir
    tracker.wide_index = index
    tracker.wide_locator = locator
    tracker.wide_calibrated = False

    base = _default_calibration(tracker.region['width'], tracker.region['height'])
    tracker.wide_calibration = WideCalibration(
        center_x=float(config.get('wide_center_x', base.center_x)),
        center_y=float(config.get('wide_center_y', base.center_y)),
        tile_width=float(config.get('wide_tile_width', base.tile_width)),
        tile_height=float(config.get('wide_tile_height', base.tile_height)),
        patch_fraction=float(config.get('wide_patch_fraction', base.patch_fraction)),
    )

    tracker.event(
        'MODO_27X27',
        f'Targuna piso {tracker.z:02d} usará localización absoluta 27x27 contra todo el mapa de ese piso.',
        initial_position=list(initial_world),
        floor=tracker.z,
        floor_dir=str(floor_dir),
        minimum_score=.80,
        minimum_gap=.10,
        route_points=len(tracker.route_targets),
        repeat_routine=tracker.repeat_routine,
        current_target=tracker._target_world(),
        compared_tiles=locator.compared_tiles,
        candidate_positions=len(locator.positions),
    )


class Tracker(Floor07Tracker):
    """Proven floor-07 tracker plus an explicit floor-08 validation path."""

    def __init__(self, routine, config):
        super().__init__(routine, config)

        if self.wide_mode or self.z not in TRIAL_WIDE_FLOORS:
            return

        try:
            _enable_floor08_wide(self, config)
        except (OSError, ValueError) as exc:
            # Do not silently fall back to 13x13 during this trial: if floor 08
            # cannot build/use a 27x27 index we want the UI to show the real cause.
            self.event(
                'MODO_27X27_NO_DISPONIBLE',
                f'No se pudo activar 27x27 en Targuna piso {self.z:02d}: {exc}',
                floor=self.z,
                error=str(exc),
            )
            raise ValueError(
                f'No se pudo activar el localizador 27x27 para Targuna piso {self.z:02d}: {exc}'
            ) from exc
