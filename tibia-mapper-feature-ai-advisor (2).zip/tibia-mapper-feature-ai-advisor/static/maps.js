(() => {
  const $ = id => document.getElementById(id);
  let zones = [], selected = null, requestId = 0, loadId = 0;
  let points = [], saved = [], saving = false;
  const outsideView = (a,b) => a.z === b.z && (Math.abs(a.x-b.x)>7 || Math.abs(a.y-b.y)>5);
  let inspectedPoint = null;
  const overlay = document.createElement('canvas');
  overlay.id = 'route-overlay'; $('viewport').appendChild(overlay);
  function drawRoute() {
    const image = $('map-image'), viewport = $('viewport');
    overlay.hidden = image.hidden || !selected;
    if (overlay.hidden) return;
    const rect = image.getBoundingClientRect(), parent = viewport.getBoundingClientRect();
    overlay.width = Math.round(rect.width); overlay.height = Math.round(rect.height);
    overlay.style.left = `${rect.left - parent.left + viewport.scrollLeft - viewport.clientLeft}px`;
    overlay.style.top = `${rect.top - parent.top + viewport.scrollTop - viewport.clientTop}px`;
    const ctx = overlay.getContext('2d');
    const [left,top,right,bottom] = selected.bbox;
    const last = points[inspectedPoint ?? points.length-1];
    if(last && last.z === Number($('floor').value)) {
      const sx=rect.width/image.naturalWidth, sy=rect.height/image.naturalHeight;
      ctx.fillStyle='rgba(34,197,94,0.30)'; ctx.strokeStyle='#ffffff'; ctx.lineWidth=5;
      ctx.fillRect((last.x-left-7)*sx,(last.y-top-5)*sy,15*sx,11*sy);
      ctx.strokeRect((last.x-left-7)*sx,(last.y-top-5)*sy,15*sx,11*sy);
      ctx.strokeStyle='#22c55e'; ctx.lineWidth=3;
      ctx.strokeRect((last.x-left-7)*sx,(last.y-top-5)*sy,15*sx,11*sy);
    }
    let previous = null;
    points.forEach((p,i) => {
      if (p.z !== Number($('floor').value) || p.x < left || p.x > right || p.y < top || p.y > bottom) { previous = null; return; }
      const x = (p.x-left+0.5)*rect.width/image.naturalWidth, y = (p.y-top+0.5)*rect.height/image.naturalHeight;
      ctx.strokeStyle = i>0 && outsideView(points[i-1],p) ? '#fbbf24' : '#38bdf8'; ctx.lineWidth = 2;
      if (previous) { ctx.beginPath(); ctx.moveTo(...previous); ctx.lineTo(x,y); ctx.stroke(); }
      ctx.beginPath(); ctx.arc(x,y,9,0,Math.PI*2); ctx.fillStyle='#082f49'; ctx.fill(); ctx.stroke();
      ctx.fillStyle='#fff'; ctx.font='bold 11px sans-serif'; ctx.textAlign='center'; ctx.textBaseline='middle'; ctx.fillText(String(i+1),x,y);
      previous=[x,y];
    });
  }
  function routeChanged() {
    $('route-status').textContent = `${points.length} puntos · ${points.filter((p,i)=>i>0 && outsideView(points[i-1],p)).length} pasos por minimapa`;
    $('route-save').disabled = saving || !points.length;
    $('route-undo').disabled = saving || !points.length;
    $('route-points').replaceChildren(...points.map((p,i) => {
      const li=document.createElement('li'), button=document.createElement('button');
      const mode=i===0 ? 'Inicio' : p.z!==points[i-1].z ? 'Cambio de piso' : outsideView(points[i-1],p) ? 'Minimapa · fuera de vista' : 'Pantalla · visible';
      li.textContent=`${p.x}, ${p.y} · piso ${p.z} · ${mode} `;
      const inspect=document.createElement('button'); inspect.textContent='Ver área'; inspect.className='secondary';
      inspect.onclick=()=>{
        inspectedPoint=i;
        const zone=zones.find(z=>z.id===p.zone_id);
        if(zone){$('region').value=zone.area;selectRegion();$('zone').value=zone.id;selectZone();$('floor').value=p.z;display();}
        drawRoute(); $('route-status').textContent=`Área visible desde el punto ${i+1}: 15 × 11 cuadros. Los nuevos pasos se añaden al final.`;
      }; li.appendChild(inspect);
      button.textContent='Quitar'; button.className='secondary'; button.disabled=saving;
      button.onclick=()=>{points.splice(i,1);inspectedPoint=null;routeChanged();}; li.appendChild(button); return li;
    })); drawRoute();
  }
  async function loadRoutes() {
    try {
      const response=await fetch('/api/map/routines'); const data=await response.json();
      if (!response.ok || !data.ok) throw new Error();
      saved=data.routines;
      options($('route-saved'), [['','Selecciona una rutina'],...saved.map(r=>[r.id,r.name])]);
    } catch (_) { $('route-status').textContent='No se pudo cargar la lista de rutinas guardadas.'; }
  }
  function options(element, items) {
    element.replaceChildren(...items.map(([value, label]) => new Option(label, value)));
    element.disabled = !items.length;
  }
  function resize() {
    const image = $('map-image');
    image.classList.toggle('fit', $('zoom').value === 'fit');
    image.style.width = $('zoom').value === 'fit' ? '' : `${image.naturalWidth * Number($('zoom').value)}px`;
    drawRoute();
  }
  async function display() {
    const id = ++requestId;
    selected = zones.find(z => z.id === $('zone').value);
    $('map-image').hidden = true;
    overlay.hidden = true;
    $('markers').replaceChildren();
    $('coordinates').textContent = 'Mueve el cursor sobre el mapa para consultar coordenadas.';
    if (!selected) return;
    const zone = selected, floor = $('floor').value;
    $('title').textContent = `${zone.name} · Piso ${floor}`;
    $('bounds').textContent = `X: ${zone.bbox[0]}–${zone.bbox[2]} · Y: ${zone.bbox[1]}–${zone.bbox[3]}`;
    $('legend').hidden = $('layer').value !== 'pathfinding';
    $('status').textContent = 'Cargando mapa…';
    $('marker-status').textContent = 'Cargando marcadores…';
    const base = `/api/map/zones/${encodeURIComponent(zone.id)}/floors/${floor}/`;
    const image = new Image();
    image.onload = () => {
      if (id !== requestId) return;
      image.id = 'map-image'; image.alt = `${zone.name}, piso ${floor}, ${$('layer').selectedOptions[0].textContent}`;
      $('map-image').replaceWith(image); resize();
      $('viewport').scrollTo(0, 0);
      $('status').textContent = 'Mapa listo.';
      image.onmousemove = event => {
        const rect = image.getBoundingClientRect();
        const x = zone.bbox[0] + Math.min(image.naturalWidth - 1, Math.floor((event.clientX - rect.left) * image.naturalWidth / rect.width));
        const y = zone.bbox[1] + Math.min(image.naturalHeight - 1, Math.floor((event.clientY - rect.top) * image.naturalHeight / rect.height));
        $('coordinates').textContent = `X: ${x} · Y: ${y} · Piso: ${floor}`;
      };
      image.onclick = event => {
        if (!$('route-draw').checked || saving) return;
        if (points.length >= 1000) { $('route-status').textContent='Máximo 1000 puntos por rutina.'; return; }
        const rect=image.getBoundingClientRect();
        const point = {x:zone.bbox[0]+Math.min(image.naturalWidth-1,Math.max(0,Math.floor((event.clientX-rect.left)*image.naturalWidth/rect.width))),
          y:zone.bbox[1]+Math.min(image.naturalHeight-1,Math.max(0,Math.floor((event.clientY-rect.top)*image.naturalHeight/rect.height))),
          z:Number(floor),zone_id:zone.id};
        points.push(point); inspectedPoint=null; routeChanged();
      };
    };
    image.onerror = () => { if (id === requestId) $('status').textContent = 'No se pudo cargar este mapa. Actualiza los datos e inténtalo de nuevo.'; };
    image.src = base + $('layer').value;
    try {
      const response = await fetch(base + 'markers', {cache: 'no-cache'});
      if (!response.ok) throw new Error();
      const markers = await response.json();
      if (id !== requestId) return;
      $('marker-status').textContent = markers.length ? `${markers.length} marcadores` : 'Sin marcadores en este piso.';
      $('markers').replaceChildren(...markers.map(marker => {
        const li = document.createElement('li'), position = document.createElement('small');
        li.textContent = marker.description || marker.icon || 'Marcador';
        position.textContent = `X: ${marker.x} · Y: ${marker.y} · ${marker.icon || ''}`;
        li.appendChild(position); return li;
      }));
    } catch (_) { if (id === requestId) $('marker-status').textContent = 'No se pudieron cargar los marcadores.'; }
  }
  function selectZone() {
    const zone = zones.find(z => z.id === $('zone').value);
    const previous = Number($('floor').value || 7);
    options($('floor'), (zone?.floors || []).map(z => [z, z === 7 ? '7 · Superficie' : String(z)]));
    if (zone?.floors.includes(previous)) $('floor').value = previous;
    display();
  }
  function selectRegion() {
    options($('zone'), zones.filter(z => z.area === $('region').value).map(z => [z.id, z.name]));
    selectZone();
  }
  async function load() {
    const id = ++loadId; ++requestId;
    $('reload').disabled = true; $('map-image').hidden = true;
    $('markers').replaceChildren(); $('marker-status').textContent = 'Selecciona una zona.';
    $('title').textContent = 'Explorador'; $('bounds').textContent = '';
    $('summary').textContent = ''; $('legend').hidden = true;
    $('status').textContent = 'Cargando zonas…'; $('empty').hidden = true;
    try {
      const response = await fetch('/api/map/zones', {cache: 'no-cache'});
      const data = await response.json();
      if (!response.ok || !data.ok) throw new Error();
      if (id !== loadId) return;
      zones = data.zones;
      const regions = [...new Set(zones.map(z => z.area))].sort((a,b) => a.localeCompare(b));
      options($('region'), regions.map(r => [r,r]));
      $('summary').textContent = `${regions.length} regiones · ${zones.length} zonas`;
      $('empty').hidden = !!zones.length;
      selectRegion();
      if (!zones.length) { $('status').textContent = 'Aún no hay zonas disponibles.'; $('marker-status').textContent = 'Sin zonas disponibles.'; }
    } catch (_) {
      zones = []; selected = null;
      ['region','zone','floor'].forEach(id => options($(id), []));
      $('status').textContent = 'No se pudo cargar el catálogo. Pulsa «Actualizar zonas» para reintentar.';
    } finally { if (id === loadId) $('reload').disabled = false; }
  }
  $('region').onchange = selectRegion; $('zone').onchange = selectZone;
  $('floor').onchange = display; $('layer').onchange = display;
  $('zoom').onchange = resize; $('reload').onclick = load;
  $('route-undo').onclick=()=>{points.pop();inspectedPoint=null;routeChanged();};
  $('route-clear').onclick=()=>{if(points.length && !confirm('¿Descartar el trazado actual y empezar otra rutina?')) return; points=[]; $('route-name').value='';routeChanged();};
  $('route-saved').onchange=()=>{
    const routine=saved.find(r=>r.id===$('route-saved').value); if(!routine) return;
    if(points.length && !confirm('¿Reemplazar el trazado actual por la rutina guardada?')) return;
    points=routine.points.map(p=>({...p})); $('route-name').value=routine.name;
    const zone=zones.find(z=>z.id===points[0]?.zone_id);
    if(zone){$('region').value=zone.area;selectRegion();$('zone').value=zone.id;selectZone();$('floor').value=points[0].z;display();}
    routeChanged();
  };
  $('route-save').onclick=async()=>{
    if(saving || !points.length)return;
    saving=true; routeChanged();
    $('route-clear').disabled=true; $('route-saved').disabled=true;
    try {
      const response=await fetch('/api/map/routines',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:$('route-name').value,points})});
      const data=await response.json(); if(!response.ok || !data.ok) throw new Error(data.error || 'No se pudo guardar.');
      await loadRoutes(); $('route-status').textContent=`Rutina «${data.routine.name}» guardada (${points.length} puntos).`;
    }catch(error){$('route-status').textContent=error.message;}
    finally{saving=false;$('route-save').disabled=!points.length;$('route-undo').disabled=!points.length;$('route-clear').disabled=false;$('route-saved').disabled=false;$('route-points').querySelectorAll('button').forEach(button=>button.disabled=false);}
  };
  window.addEventListener('resize',drawRoute);
  routeChanged(); loadRoutes();
  load();
})();
