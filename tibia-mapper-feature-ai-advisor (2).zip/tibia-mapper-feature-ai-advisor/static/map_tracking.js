(() => {
  const $=id=>document.getElementById(id);
  const SAMPLE_DELAY_MS=250;
  let running=false, selectingInitial=false, busy=false, timer=null, captureReady=false;
  let origin=[0,0], plan=[], background=null, last={}, corner=null, viewLeft=0, viewTop=0;

  async function api(url,body){
    const r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body||{})});
    const text=await r.text();
    let d;
    try{d=JSON.parse(text);}catch(_){
      const detail=text.trim().startsWith('<')?'El servidor devolvió HTML; probablemente la ruta API no existe en la versión del backend que está ejecutándose.':'Respuesta no JSON del servidor.';
      throw Error(`${detail} HTTP ${r.status} en ${url}`);
    }
    if(!r.ok||!d.ok)throw Error(d.error||`Error HTTP ${r.status} en ${url}`);
    return d;
  }

  async function mover(direccion,guidance={}){
    return api('/api/map/tracking/movement/log',{
      direction:direccion,
      mode:guidance.mode||null,
      target:Array.isArray(guidance.target)?guidance.target:null,
      pending_target:Array.isArray(guidance.pending_target)?guidance.pending_target:null,
      target_index:Number.isInteger(guidance.target_index)?guidance.target_index:null,
      cycle:Number.isInteger(guidance.cycle)?guidance.cycle:null,
      steps:Number.isFinite(guidance.steps)?guidance.steps:null
    });
  }

  async function procesarMovimiento(data){
    const guidance=data.guidance||{};
    const direccion=guidance.direction;
    if(!direccion)return;

    // Una instrucción válida debe volver a enviarse en cada muestra confirmada.
    // Esto evita quedar detenido justo al reingresar a la ruta si la primera
    // pulsación del nuevo modo (return -> route) no alcanza a producir movimiento.
    await mover(direccion,guidance);
  }

  function draw(){
    if(!background)return;
    const canvas=$('tracking-map'),ctx=canvas.getContext('2d');
    const all=[...plan,...(last.return_path||[]),...(last.position?[last.position]:[])];
    if(!all.length)return;
    const extent=all.reduce((a,p)=>[
      Math.min(a[0],p[0]-origin[0]),Math.min(a[1],p[1]-origin[1]),
      Math.max(a[2],p[0]-origin[0]),Math.max(a[3],p[1]-origin[1])
    ],[Infinity,Infinity,-Infinity,-Infinity]);
    viewLeft=Math.max(0,extent[0]-30);viewTop=Math.max(0,extent[1]-30);
    const right=Math.min(background.naturalWidth,extent[2]+31),bottom=Math.min(background.naturalHeight,extent[3]+31);
    canvas.width=Math.max(1,right-viewLeft);canvas.height=Math.max(1,bottom-viewTop);
    ctx.drawImage(background,viewLeft,viewTop,canvas.width,canvas.height,0,0,canvas.width,canvas.height);
    function line(points,color){
      if(!points.length)return;
      ctx.strokeStyle=color;ctx.lineWidth=1;ctx.beginPath();
      points.forEach((p,i)=>{const x=p[0]-origin[0]-viewLeft+.5,y=p[1]-origin[1]-viewTop+.5;i?ctx.lineTo(x,y):ctx.moveTo(x,y);});ctx.stroke();
    }
    line(plan,'#38bdf8');
    line(last.return_path||[],'#fde047');
    if(last.position){
      const x=last.position[0]-origin[0]-viewLeft,y=last.position[1]-origin[1]-viewTop;
      ctx.fillStyle='#ff3333';ctx.fillRect(x,y,1,1);
    }
    const zoom=Number($('tracking-zoom').value);canvas.style.maxWidth=zoom===1?'100%':'none';canvas.style.width=zoom===1?'100%':`${canvas.width*zoom}px`;
    canvas.style.cursor=selectingInitial?'crosshair':'default';
  }

  function directions(path){
    let result=[],count=0,previous='';
    for(let i=1;i<path.length;i++){
      const dx=path[i][0]-path[i-1][0],dy=path[i][1]-path[i-1][1];
      const direction=dx>0?'Este':dx<0?'Oeste':dy>0?'Sur':'Norte';
      if(direction!==previous&&count){result.push(`${previous} ${count}`);count=0;}
      previous=direction;count++;
    }
    if(count)result.push(`${previous} ${count}`);return result.join(' → ');
  }

  function renderGuidance(data){
    const guidance=data.guidance;
    if(guidance){
      const title=guidance.mode==='return'?'VOLVER A LA RUTA':'SEGUIR RUTA';
      const direction=guidance.direction?`Dirección: ${guidance.direction}`:'Dirección: fin de ruta';
      const target=guidance.target?`\nObjetivo: ${guidance.target.join(', ')}`:'';
      const steps=Number.isFinite(guidance.steps)?`\nDistancia: ${guidance.steps} cuadro(s)`:'';
      const cycle=data.repeat_routine?`\nCiclo: ${data.cycle}`:'';
      $('return-steps').textContent=`${title}\n${direction}${target}${steps}${cycle}\n${guidance.message}`;
      return;
    }
    $('return-steps').textContent='Esperando una posición válida para indicar la dirección.';
  }

  async function sample(){
    if(!running||busy)return;busy=true;
    try{
      const data=await api('/api/map/tracking/sample');
      if(!running)return;
      await procesarMovimiento(data);
      last=data;draw();renderGuidance(data);
      const effectiveState=data.route_candidate||data.state;
      const stateLabel=({unknown:'Posición no validada',on_route:'En ruta',deviated:'Fuera de ruta'})[effectiveState]||effectiveState;
      const confidence=data.confidence?` · Coincidencia ${(data.confidence*100).toFixed(1)} %`:'';
      const delta=data.delta&&data.delta.some(v=>v)?` · Movimiento ${data.delta[0]},${data.delta[1]}`:'';
      const cycle=data.repeat_routine?` · Ciclo ${data.cycle}`:'';
      $('status').textContent=`${stateLabel}${cycle} · ${data.message}${confidence}${delta}`;
      $('tracking-log').textContent=data.events.slice().reverse().map(e=>`${e.time} [${e.kind}] ${e.message}${e.path?' '+directions(e.path):''}`).join('\n');
    }catch(e){
      $('status').textContent=e.message;
      $('return-steps').textContent='No se pudo validar la posición; se conserva la última conocida.';
    }finally{
      busy=false;if(running)timer=setTimeout(sample,SAMPLE_DELAY_MS);
    }
  }

  async function configureObs(){
    const sourceNode=$('obs-source');
    return api('/api/map/tracking/obs',{
      scene:$('obs-scene').value,
      source:sourceNode?sourceNode.value:'',
      port:Number($('obs-port').value),
      password:$('obs-password').value
    });
  }

  $('capture-button').onclick=async()=>{
    if(running||selectingInitial){$('status').textContent='Detén o cancela la selección inicial antes de cambiar la captura.';return;}
    $('capture-button').disabled=true;captureReady=false;
    try{
      const config=await configureObs();
      const response=await fetch('/api/map/tracking/capture?t='+Date.now());
      if(!response.ok){
        const text=await response.text();let data={};try{data=JSON.parse(text);}catch(_){}
        throw Error(data.error||`No se pudo capturar desde OBS. HTTP ${response.status}`);
      }
      const directSource=config.mode==='source',target=config.target;
      const url=URL.createObjectURL(await response.blob()),image=$('capture');
      image.onload=()=>{
        URL.revokeObjectURL(url);image.hidden=false;corner=null;
        if(directSource){
          $('x').value=0;$('y').value=0;$('width').value=image.naturalWidth;$('height').value=image.naturalHeight;
          captureReady=true;
          $('capture-help').textContent=`Fuente OBS “${target}” lista (${image.naturalWidth}×${image.naturalHeight}). La calibración 27×27 se ajustará automáticamente al iniciar.`;
          $('status').textContent='Captura lista. Elige la rutina e inicia seguimiento.';
        }else{
          $('capture-help').textContent='Escena completa capturada. Marca dos esquinas del minimapa para definir solo el recorte; la geometría 27×27 se calibrará automáticamente.';
          $('status').textContent='Marca las dos esquinas del minimapa en la captura.';
        }
      };
      image.onerror=()=>{URL.revokeObjectURL(url);$('status').textContent='Imagen OBS inválida.';};
      image.src=url;
    }catch(e){$('status').textContent=e.message;}finally{$('capture-button').disabled=false;}
  };

  $('capture').onclick=e=>{
    if(running||selectingInitial)return;
    const image=$('capture'),r=image.getBoundingClientRect();
    const point=[Math.floor((e.clientX-r.left)*image.naturalWidth/r.width),Math.floor((e.clientY-r.top)*image.naturalHeight/r.height)];
    if(!corner){corner=point;captureReady=false;$('capture-help').textContent=`Primera esquina ${point}. Marca la esquina opuesta.`;}
    else{
      ['x','y'].forEach((k,i)=>$(k).value=Math.min(corner[i],point[i]));
      $('width').value=Math.max(1,Math.abs(point[0]-corner[0]));$('height').value=Math.max(1,Math.abs(point[1]-corner[1]));corner=null;
      captureReady=true;$('capture-help').textContent='Recorte listo. La calibración 27×27 se resolverá automáticamente usando la posición inicial.';
      $('status').textContent='Recorte listo. Ya puedes iniciar seguimiento.';
    }
  };

  async function beginAt(worldX,worldY){
    try{
      const payload={
        routine_id:$('routine').value,
        initial_x:worldX,
        initial_y:worldY,
        repeat_routine:Boolean($('repeat-routine')?.checked)
      };
      ['x','y','width','height'].forEach(k=>payload[k]=Number($(k).value));
      const data=await api('/api/map/tracking/start',payload);
      selectingInitial=false;running=true;
      last={position:data.position,return_path:[]};draw();
      $('log-file').textContent=`Registro guardado en logs/${data.log_file}`;
      $('status').textContent=`Posición inicial ${data.position.join(', ')}. Localizador ${data.locator_mode}; calibración automática al primer muestreo.`;
      $('start').disabled=true;$('stop').disabled=false;sample();
    }catch(e){
      selectingInitial=false;$('start').disabled=false;$('status').textContent=e.message;draw();
    }
  }

  $('tracking-map').onclick=e=>{
    if(!selectingInitial||!background)return;
    const canvas=$('tracking-map'),r=canvas.getBoundingClientRect();
    const localX=Math.floor((e.clientX-r.left)*canvas.width/r.width)+viewLeft;
    const localY=Math.floor((e.clientY-r.top)*canvas.height/r.height)+viewTop;
    const worldX=origin[0]+localX,worldY=origin[1]+localY;
    last={position:[worldX,worldY],return_path:[]};draw();
    $('status').textContent=`Posición inicial marcada: ${worldX}, ${worldY}. Iniciando validación...`;
    beginAt(worldX,worldY);
  };

  $('start').onclick=async()=>{
    if(running||busy||selectingInitial)return;
    if(!captureReady){$('status').textContent='Primero captura la fuente Mapa o selecciona el recorte del minimapa.';return;}
    $('start').disabled=true;
    try{
      const data=await api('/api/map/tracking/prepare',{routine_id:$('routine').value});
      origin=data.origin;plan=data.plan;last={};selectingInitial=true;background=new Image();
      background.onload=()=>{draw();$('status').textContent='Haz clic en el mapa exactamente donde está tu personaje ahora. Esa posición permite calibrar automáticamente el localizador 27×27.';};
      background.onerror=()=>{selectingInitial=false;$('start').disabled=false;$('status').textContent='No se pudo cargar el mapa del piso.';};
      background.src=`/api/map/tracking/floor/${data.z}?t=${Date.now()}`;
    }catch(e){$('status').textContent=e.message;$('start').disabled=false;}
  };

  $('stop').onclick=async()=>{
    selectingInitial=false;
    if(!running){$('start').disabled=false;draw();return;}
    running=false;clearTimeout(timer);$('stop').disabled=true;
    try{await api('/api/map/tracking/stop');$('status').textContent='Seguimiento detenido.';}
    catch(e){$('status').textContent=e.message;}
    finally{$('start').disabled=false;draw();}
  };

  $('tracking-zoom').onchange=draw;
  fetch('/api/map/routines').then(async r=>{
    const text=await r.text();let d;try{d=JSON.parse(text);}catch(_){throw Error('La API de rutinas devolvió HTML en vez de JSON. Reinicia el backend después de actualizar.');}
    return d;
  }).then(d=>{
    $('routine').replaceChildren(...d.routines.map(r=>new Option(r.name,r.id)));
    if(!d.routines.length)$('status').textContent='Primero guarda una rutina desde Mapas por zonas.';
  }).catch(e=>{$('status').textContent=e.message||'No se pudieron cargar las rutinas.';});
})();
