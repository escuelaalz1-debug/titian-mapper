"""Generate named, rectangular map extracts without modifying the upstream clone."""
from __future__ import annotations

import json
import re
import tempfile
import unicodedata
from pathlib import Path

from PIL import Image


def slug(value: str) -> str:
    value = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode()
    return re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def pathfinding_file(source: Path, z: int) -> Path:
    canonical = source / f"floor-{z:02d}-path.png"
    return canonical if canonical.exists() else source / f"floor-{z:02d}-pathfinding.png"


def organize_maps(source: Path, destination: Path, catalog_path: Path) -> dict:
    source, destination = source.resolve(), destination.resolve()
    if source == destination or source in destination.parents or destination in source.parents:
        raise ValueError("La salida debe estar separada de los datos originales.")
    bounds = read_json(source / "bounds.json")
    markers = read_json(source / "markers.json")
    catalog = read_json(catalog_path)
    xmin, ymin = int(bounds["xMin"]), int(bounds["yMin"])
    xmax, ymax = xmin + int(bounds["width"]) - 1, ymin + int(bounds["height"]) - 1
    floors = list(range(int(bounds.get("zMin", 0)), int(bounds.get("zMax", 15)) + 1))
    zones, paths = [], set()
    for item in catalog["zones"]:
        left, top, right, bottom = map(int, item["bbox"])
        if left > right or top > bottom:
            raise ValueError(f"Límites inválidos: {item['id']}")
        left, top, right, bottom = max(left, xmin), max(top, ymin), min(right, xmax), min(bottom, ymax)
        if left > right or top > bottom:
            continue
        relative = f"{slug(item['area'])}/{slug(item['id'])}"
        if not all(relative.split("/")) or relative in paths:
            raise ValueError(f"Carpeta de zona vacía o duplicada: {relative}")
        paths.add(relative)
        zones.append({"id": item["id"], "area": item["area"], "name": item["subarea"],
                      "path": relative, "bbox": [left, top, right, bottom], "floors": floors})
    if not zones:
        raise ValueError("No hay zonas dentro de los límites del mapa.")
    destination.parent.mkdir(parents=True, exist_ok=True)
    # Build completely before replacing the previous cache; failures preserve it.
    with tempfile.TemporaryDirectory(prefix=".tibia-zones-", dir=destination.parent) as temporary:
        staging = Path(temporary) / "ready"
        staging.mkdir()
        for zone in zones:
            folder = staging / zone["path"]
            write_json(folder / "zone.json", zone)
            left, top, right, bottom = zone["bbox"]
            selected = [m for m in markers if left <= int(m["x"]) <= right and top <= int(m["y"]) <= bottom]
            for z in floors:
                write_json(folder / "floors" / f"{z:02d}" / "markers.json",
                           [m for m in selected if int(m["z"]) == z])
        for z in floors:
            for layer in ("map", "pathfinding"):
                path = source / f"floor-{z:02d}-{layer}.png"
                if layer == "pathfinding":
                    path = pathfinding_file(source, z)
                with Image.open(path) as image:
                    if image.size != (bounds["width"], bounds["height"]):
                        raise ValueError(f"Dimensiones incorrectas: {path}")
                    image.load()
                    for zone in zones:
                        left, top, right, bottom = zone["bbox"]
                        crop = image.crop((left-xmin, top-ymin, right-xmin+1, bottom-ymin+1))
                        crop.save(staging / zone["path"] / "floors" / f"{z:02d}" / f"{layer}.png")
        index = {"version": 1, "layout": "area/subarea/floors/ZZ",
                 "coverage": "rectangular-bounding-boxes", "source": catalog.get("source"),
                 "bounds": bounds, "zones": zones}
        write_json(staging / "index.json", index)
        # Unknown directories are never replaced.
        if destination.exists() and not (destination / "index.json").is_file():
            raise ValueError(f"La salida ya existe y no es una caché de zonas: {destination}")
        previous = Path(temporary) / "previous"
        if destination.exists():
            destination.rename(previous)
        try:
            staging.rename(destination)
        except OSError:
            if previous.exists():
                previous.rename(destination)
            raise
    return index
